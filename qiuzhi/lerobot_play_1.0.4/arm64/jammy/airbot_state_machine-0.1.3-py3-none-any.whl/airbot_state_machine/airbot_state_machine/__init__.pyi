"""
Python bindings for state_machine module
"""
from __future__ import annotations
from . import robotic_arm
__all__: list[str] = ['robotic_arm']
