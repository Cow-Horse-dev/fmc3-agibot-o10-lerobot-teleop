"""
Python bindings for Airbot robotic arm state_machine module
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['ArmPos', 'ArmState', 'ArmTrajectory', 'CSP', 'CSV', 'ControlMode', 'DEFAULT', 'E2', 'EEFType', 'G2', 'GRAVITY_COMPENSATION', 'INVALID', 'LINEAR', 'MIT', 'NA', 'PLANNING', 'PTP', 'PVT', 'PlanStrategy', 'RECORDING', 'RECORDING_HALT', 'RECORDING_IDLE', 'REPLAYING', 'REPLAYING_HALT', 'RRT', 'RoboticArm']
class ArmPos:
    """
    
    A single timestamped robot pose used for recording and replay.
    
    Attributes
    ----------
    arm_state : list[float]
        6 joint positions in radians (order: joint 0 .. joint 5).
    eef_pos : float
        End-effector position. Units depend on the attached EEF (e.g., meters).
    time_from_start_ms : float (property)
        Time from the start of the trajectory in milliseconds.
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def arm_state(self) -> typing.Annotated[list[float], "FixedSize(6)"]:
        """
        Array of 6 joint positions (radians).
        """
    @arm_state.setter
    def arm_state(self, arg0: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"]) -> None:
        ...
    @property
    def eef_pos(self) -> float:
        """
        End-effector position (units depend on EEF).
        """
    @eef_pos.setter
    def eef_pos(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def time_from_start_ms(self) -> float:
        """
        Time from trajectory start in milliseconds (float).
        """
    @time_from_start_ms.setter
    def time_from_start_ms(self, arg1: typing.SupportsFloat) -> None:
        ...
class ArmState:
    """
    Represents the different states of the robotic arm.
    
    Members:
    
      DEFAULT : Default idle state.
    
      PLANNING : Planning motion state.
    
      GRAVITY_COMPENSATION : Gravity compensation mode.
    
      RECORDING_IDLE : Recording subsystem initialized; not recording.
    
      RECORDING : Currently recording arm states.
    
      RECORDING_HALT : Recording paused.
    
      REPLAYING : Replaying a recorded trajectory.
    
      REPLAYING_HALT : Replay paused.
    """
    DEFAULT: typing.ClassVar[ArmState]  # value = <ArmState.DEFAULT: 0>
    GRAVITY_COMPENSATION: typing.ClassVar[ArmState]  # value = <ArmState.GRAVITY_COMPENSATION: 2>
    PLANNING: typing.ClassVar[ArmState]  # value = <ArmState.PLANNING: 1>
    RECORDING: typing.ClassVar[ArmState]  # value = <ArmState.RECORDING: 5>
    RECORDING_HALT: typing.ClassVar[ArmState]  # value = <ArmState.RECORDING_HALT: 6>
    RECORDING_IDLE: typing.ClassVar[ArmState]  # value = <ArmState.RECORDING_IDLE: 4>
    REPLAYING: typing.ClassVar[ArmState]  # value = <ArmState.REPLAYING: 7>
    REPLAYING_HALT: typing.ClassVar[ArmState]  # value = <ArmState.REPLAYING_HALT: 8>
    __members__: typing.ClassVar[dict[str, ArmState]]  # value = {'DEFAULT': <ArmState.DEFAULT: 0>, 'PLANNING': <ArmState.PLANNING: 1>, 'GRAVITY_COMPENSATION': <ArmState.GRAVITY_COMPENSATION: 2>, 'RECORDING_IDLE': <ArmState.RECORDING_IDLE: 4>, 'RECORDING': <ArmState.RECORDING: 5>, 'RECORDING_HALT': <ArmState.RECORDING_HALT: 6>, 'REPLAYING': <ArmState.REPLAYING: 7>, 'REPLAYING_HALT': <ArmState.REPLAYING_HALT: 8>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __ge__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __gt__(self, other: typing.Any) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __le__(self, other: typing.Any) -> bool:
        ...
    def __lt__(self, other: typing.Any) -> bool:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ArmTrajectory:
    """
    
    A recorded trajectory consisting of a sequence of ArmPos samples.
    
    Attributes
    ----------
    trajectory : list[ArmPos]
        Ordered list of samples (ArmPos).
    use_eef : bool
        Whether the trajectory includes end-effector state.
    """
    def __init__(self) -> None:
        ...
    def __len__(self) -> int:
        ...
    def __repr__(self) -> str:
        ...
    def clear(self) -> None:
        """
        Clear all recorded samples.
        """
    @property
    def trajectory(self) -> list[ArmPos]:
        """
        List of ArmPos samples.
        """
    @trajectory.setter
    def trajectory(self, arg0: collections.abc.Sequence[ArmPos]) -> None:
        ...
    @property
    def use_eef(self) -> bool:
        """
        If true, each sample includes end-effector state.
        """
    @use_eef.setter
    def use_eef(self, arg0: bool) -> None:
        ...
class ControlMode:
    """
    Control modes for the robotic arm (used with set_param("arm.control_mode", ...)).
    
    Members:
    
      INVALID : Invalid mode, should not be used.
    
      MIT : 
    MIT mode:
      Torque/impedance control using position, velocity, and torque commands
      with proportional (Kp) and derivative (Kd) gains.
    
    
      CSP : Cyclic Synchronous Position mode.
    
      CSV : Cyclic Synchronous Velocity mode.
    
      PVT : Position-Velocity-Torque mode with current threshold.
    """
    CSP: typing.ClassVar[ControlMode]  # value = <ControlMode.CSP: 2>
    CSV: typing.ClassVar[ControlMode]  # value = <ControlMode.CSV: 3>
    INVALID: typing.ClassVar[ControlMode]  # value = <ControlMode.INVALID: 0>
    MIT: typing.ClassVar[ControlMode]  # value = <ControlMode.MIT: 1>
    PVT: typing.ClassVar[ControlMode]  # value = <ControlMode.PVT: 4>
    __members__: typing.ClassVar[dict[str, ControlMode]]  # value = {'INVALID': <ControlMode.INVALID: 0>, 'MIT': <ControlMode.MIT: 1>, 'CSP': <ControlMode.CSP: 2>, 'CSV': <ControlMode.CSV: 3>, 'PVT': <ControlMode.PVT: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class EEFType:
    """
    Types of supported end-effectors.
    
    Members:
    
      NA : No end-effector attached.
    
      G2 : G2 gripper.
    
      E2 : E2 tool.
    """
    E2: typing.ClassVar[EEFType]  # value = <EEFType.E2: 2>
    G2: typing.ClassVar[EEFType]  # value = <EEFType.G2: 1>
    NA: typing.ClassVar[EEFType]  # value = <EEFType.NA: 0>
    __members__: typing.ClassVar[dict[str, EEFType]]  # value = {'NA': <EEFType.NA: 0>, 'G2': <EEFType.G2: 1>, 'E2': <EEFType.E2: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class PlanStrategy:
    """
    Available motion planning strategies.
    
    Members:
    
      PTP : Point-to-point motion planning.
    
      LINEAR : Linear interpolation between waypoints.
    
      RRT : Rapidly-exploring Random Tree planning.
    """
    LINEAR: typing.ClassVar[PlanStrategy]  # value = <PlanStrategy.LINEAR: 1>
    PTP: typing.ClassVar[PlanStrategy]  # value = <PlanStrategy.PTP: 0>
    RRT: typing.ClassVar[PlanStrategy]  # value = <PlanStrategy.RRT: 2>
    __members__: typing.ClassVar[dict[str, PlanStrategy]]  # value = {'PTP': <PlanStrategy.PTP: 0>, 'LINEAR': <PlanStrategy.LINEAR: 1>, 'RRT': <PlanStrategy.RRT: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __ge__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __gt__(self, other: typing.Any) -> bool:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __le__(self, other: typing.Any) -> bool:
        ...
    def __lt__(self, other: typing.Any) -> bool:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class RoboticArm:
    """
    High-level interface class for controlling a 6-DOF robotic arm.
    """
    def __init__(self) -> None:
        """
        Construct a new RoboticArm object.
        """
    def eef_get_position(self) -> float:
        """
        Get the current end-effector position.
        """
    def eef_get_torque(self) -> float:
        """
        Get the current end-effector torque.
        """
    def eef_get_velocity(self) -> float:
        """
        Get the current end-effector velocity.
        """
    def eef_mit(self, position: typing.SupportsFloat, velocity: typing.SupportsFloat = 0.0, torque: typing.SupportsFloat = 0.0, kp: typing.SupportsFloat = 0.0, kd: typing.SupportsFloat = 0.0) -> bool:
        """
        Command EEF position, velocity, torque with PD gains (MIT-like).
        
        Parameters
        ----------
        position : float
            Target EEF position.
        velocity : float, optional
            Target EEF velocity. Default: 0.0.
        torque : float, optional
            Target EEF torque/force. Default: 0.0.
        kp : float, optional
            Proportional gain. Default: 0.0.
        kd : float, optional
            Derivative gain. Default: 0.0.
        
        Returns
        -------
        bool
            True if command accepted.
        """
    def eef_pvt(self, position: typing.SupportsFloat, velocity: typing.SupportsFloat = 0.0, torque: typing.SupportsFloat = 0.0) -> bool:
        """
        Command EEF position, velocity, and torque (PVT-like interface).
        
        Parameters
        ----------
        position : float
            Target EEF position (units depend on attached EEF).
        velocity : float, optional
            Target EEF velocity (units/time). Default: 0.0.
        torque : float, optional
            Target EEF torque/force. Default: 0.0.
        
        Returns
        -------
        bool
            True if the command was accepted by the controller.
        """
    def executor_halt(self) -> bool:
        """
        Halt the current motion execution immediately.
        """
    def executor_resume(self) -> bool:
        """
        Resume motion execution after being halted.
        """
    def get_current_state(self) -> ArmState:
        """
        Get the current ArmState.
        """
    def get_eef_type(self) -> EEFType:
        """
        Return the type of the end-effector.
        """
    def get_position(self) -> typing.Annotated[list[float], "FixedSize(6)"]:
        """
        Get current joint positions (array of 6 floats, radians).
        """
    def get_torque(self) -> typing.Annotated[list[float], "FixedSize(6)"]:
        """
        Get current joint torques (array of 6 floats, N·m).
        """
    def get_velocity(self) -> typing.Annotated[list[float], "FixedSize(6)"]:
        """
        Get current joint velocities (array of 6 floats, rad/s).
        """
    def gravity_calibrate(self) -> bool:
        """
        Run gravity compensation calibration routine (blocking).
        
        This launches the internal multi-phase gravity calibration state machine:
          1. Moves the arm through predefined joint poses.
          2. At each pose, samples joint torques over a fixed number of control cycles.
          3. Compares measured torques with model-predicted gravity torques.
          4. Estimates per-joint gravity compensation coefficients and applies them
             to the internal dynamics model.
        
        Behavior
        --------
        - This call is **blocking** from Python's point of view, but it releases the
          Python GIL internally, so other Python threads can continue to run.
        - Internally, the arm switches to ArmState.GRAVITY_CALIBRATION while the
          routine is running.
        - On success, the arm is brought back to a neutral configuration and the
          state returns to ArmState.DEFAULT.
        
        Safety / Requirements
        ---------------------
        - The arm must be initialized with `initialize()` beforehand.
        - Current state must be compatible (e.g. DEFAULT / GRAVITY_COMPENSATION /
          RECORDING_IDLE / RECORDING_HALT); otherwise the function returns False.
        - A valid dynamics model must be available internally (URDF loaded).
        
        Returns
        -------
        bool
            True if calibration finished successfully and coefficients were applied.
            False if calibration could not start (invalid state, missing dynamics),
            or aborted due to timeout/other internal errors.
        
        Example
        -------
        >>> arm = RoboticArm()
        >>> ok = arm.initialize("can0", "/path/to/urdf.urdf")
        >>> if not ok:
        ...     raise RuntimeError("Failed to initialize robot")
        >>> if not arm.gravity_calibrate():
        ...     print("Gravity calibration failed")
        ... else:
        ...     print("Gravity calibration succeeded")
        """
    def has_eef(self) -> bool:
        """
        Check whether an end-effector is attached.
        """
    def initialize(self, can_interface: str = 'can0', urdf_path: str = '/root/asset/play_g2/urdf/play_g2.urdf') -> bool:
        """
        Initialize the robotic arm hardware and software.
        
        Parameters
        ----------
        can_interface : str, optional
            The CAN bus interface to use (default: \\"can0\\").
        urdf_path : str, optional
            Path to the robot's URDF model file (default: \\"/root/asset/play_g2/urdf/play_g2.urdf\\").
        
        Returns
        -------
        bool
            True if initialization succeeds; False otherwise.
        
        Notes
        -----
        - This call may perform I/O and spawn threads. It is a blocking call and may take several seconds.
        - No exceptions are thrown by this method; failures are indicated via the boolean return value.
        """
    def is_running(self) -> bool:
        """
        Check if the robotic arm is currently running/executing motion.
        """
    def mit(self, position: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"], velocity: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"], torque: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"], kp: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"], kd: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"]) -> None:
        """
        Command joint positions, velocities, torques with PD gains (MIT control).
        
        Parameters
        ----------
        position : sequence of 6 floats
            Target joint positions (radians).
        velocity : sequence of 6 floats
            Target joint velocities (rad/s).
        torque : sequence of 6 floats
            Target joint torques (N·m).
        kp : sequence of 6 floats
            Per-joint proportional gains.
        kd : sequence of 6 floats
            Per-joint derivative gains.
        
        Notes
        -----
        This mode is intended for advanced control. Choose gains carefully and test in a safe environment.
        """
    @typing.overload
    def plan_and_execute(self, target: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"], velocity_factor: typing.SupportsFloat, plan_strategy: PlanStrategy = ..., force_calc_linear: bool = True, sampling_time: typing.SupportsFloat = 0.001) -> bool:
        """
        Plan to a single joint target (6 joint values).
        
        Notes for Python users:
        - This function schedules trajectory execution asynchronously.
        - To control execution (halt/resume) from Python, it is recommended to run it in a separate thread.
        - Example:
            import threading
            def plan_thread():
                arm.plan_and_execute([0.1,0,0,0,0,0], 0.5)
            t = threading.Thread(target=plan_thread)
            t.start()
        - You can then call arm.executor_halt() or arm.executor_resume() anytime.
        """
    @typing.overload
    def plan_and_execute(self, waypoints: collections.abc.Sequence[typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"]], velocity_factor: typing.SupportsFloat, plan_strategy: PlanStrategy = ..., force_calc_linear: bool = True, allow_blend_failure: bool = True, sampling_time: typing.SupportsFloat = 0.001) -> bool:
        """
        Plan through multiple joint waypoints.
        
        Notes for Python users:
        - Execution is asynchronous; run in a separate thread if you want to monitor or control execution.
        - Example:
            import threading
            def plan_thread():
                arm.plan_and_execute([[0.1,0,0,0,0,0],[0.2,0,0,0,0,0]], 0.5)
            t = threading.Thread(target=plan_thread)
            t.start()
        - Use arm.executor_halt() and arm.executor_resume() to pause/resume trajectory.
        """
    @typing.overload
    def plan_and_execute(self, target: tuple[typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(3)"], typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(4)"]], velocity_factor: typing.SupportsFloat, plan_strategy: PlanStrategy = ..., force_calc_linear: bool = True, sampling_time: typing.SupportsFloat = 0.001) -> bool:
        """
        Plan to a single Cartesian target (position + quaternion).
        
        Notes for Python users:
        - Execution is non-blocking; for real-time control, run in a separate Python thread.
        - Example:
            import threading
            def plan_thread():
                arm.plan_and_execute(([0.1,0,0],[1,0,0,0]), 0.5)
            t = threading.Thread(target=plan_thread)
            t.start()
        - Can call arm.executor_halt() and arm.executor_resume() during execution.
        """
    @typing.overload
    def plan_and_execute(self, waypoints: typing.Any, velocity_factor: typing.SupportsFloat, plan_strategy: PlanStrategy = ..., force_calc_linear: bool = True, allow_blend_failure: bool = True, sampling_time: typing.SupportsFloat = 0.001) -> bool:
        """
        Plan through multiple Cartesian waypoints (position + quaternion).
        
        Notes for Python users:
        - Accepts list or tuple of ([x,y,z], [w,x,y,z]); also supports numpy arrays.
        - Execution is asynchronous; run in a separate thread for monitoring.
        - Example:
            import threading
            def plan_thread():
                arm.plan_and_execute([([0.1,0,0],[1,0,0,0]), ([0.2,0,0],[1,0,0,0])], 0.5)
            t = threading.Thread(target=plan_thread)
            t.start()
        - Can call arm.executor_halt() / arm.executor_resume() during execution.
        """
    def pvt(self, position: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"], velocity: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"], torque: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"]) -> None:
        """
        Command joint positions, velocities, and maximum currents (PVT control).
        
        Parameters
        ----------
        position : sequence of 6 floats
            Target joint positions (radians).
        velocity : sequence of 6 floats
            Maximum allowed joint velocities during motion (rad/s).
        torque : sequence of 6 floats
            Maximum allowed joint currents/torques during motion (A or N·m depending on implementation).
        """
    def record_halt(self) -> bool:
        """
        Temporarily pause an ongoing recording (recorded data retained).
        """
    def record_resume(self) -> bool:
        """
        Resume a previously paused recording.
        """
    def record_start(self, sampling_time: typing.SupportsFloat, save_traj: bool, path: str, use_eef: bool) -> bool:
        """
        Start recording joint and optional end-effector trajectories.
        
        Parameters
        ----------
        sampling_time : float
            Sampling period in seconds for recording.
        save_traj : bool
            If True, persist the recorded trajectory to `path` when recording stops.
        path : str
            Filesystem path used for persisting the trajectory if save_traj is True.
        use_eef : bool
            If True, include EEF state in recorded samples.
        
        Returns
        -------
        bool
            True if recording started successfully.
        """
    def record_stop(self, result: ArmTrajectory) -> bool:
        """
        Stop recording and retrieve the recorded trajectory.
        
        Parameters
        ----------
        result : ArmTrajectory
            Output parameter that will be populated with recorded samples.
        
        Returns
        -------
        bool
            True if recording stopped successfully and `result` contains valid data.
        """
    def replay_halt(self) -> bool:
        """
        Pause an ongoing replay without discarding state.
        """
    def replay_resume(self) -> bool:
        """
        Resume a paused replay.
        """
    def replay_start(self, target_trajectory: ArmTrajectory) -> bool:
        """
        Start replaying a previously recorded trajectory.
        
        Parameters
        ----------
        target_trajectory : ArmTrajectory
            The trajectory to replay (typically produced by record_stop()).
        
        Returns
        -------
        bool
            True if replay started successfully.
        """
    def replay_stop(self) -> bool:
        """
        Stop replaying and release resources.
        """
    def set_gravity_coefficients(self, coeff: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"]) -> None:
        """
        Set gravity coefficients.
        """
    def set_max_replay_vel(self, vel: typing.SupportsFloat) -> bool:
        """
        Set maximum replay velocity (implementation-dependent units).
        """
    def set_param(self, param_name: str, value: typing.SupportsInt) -> None:
        """
        Set a specific parameter of the robotic arm.
        
        Special case:
          - If `param_name` is \\"arm.control_mode\\", the `value` must be one of the ControlMode enum values:
              - 0 (INVALID) : Invalid mode (do not use).
              - 1 (MIT)     : MIT mode (torque/impedance with Kp/Kd).
              - 2 (CSP)     : Cyclic Synchronous Position.
              - 3 (CSV)     : Cyclic Synchronous Velocity.
              - 4 (PVT)     : Position-Velocity-Torque.
        
        Examples
        --------
        arm.set_param(\\"arm.control_mode\\", 1)  # Switch to MIT mode
        arm.set_param(\\"immediate_update\\", 1)  # Apply certain params immediately
        """
    def shutdown(self) -> None:
        """
        Shut down the robotic arm and release resources.
        
        Attempts to stop motion execution and terminate background threads. After this call the object may be re-initialized.
        """
    def switch_state(self, new_state: ArmState) -> None:
        """
        Switch the robotic arm to a new state.
        
        Parameters
        ----------
        new_state : ArmState
            Target state to request.
        
        Notes
        -----
        This call requests a state transition and returns immediately (asynchronous). Use get_current_state() to observe changes.
        """
    def vel(self, velocity: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"]) -> None:
        """
        Command joint velocities.
        
        Parameters
        ----------
        velocity : sequence of 6 floats
            Joint velocities in radians per second (joint 0 .. joint 5).
        """
    def wait_reach(self, target_position: typing.Annotated[collections.abc.Sequence[typing.SupportsFloat], "FixedSize(6)"], error_tolerance: typing.SupportsFloat = 0.01, timeout_seconds: typing.SupportsFloat = 10.0) -> bool:
        """
        Wait until the arm reaches a target joint position.
        
        Parameters
        ----------
        target_position : sequence of 6 floats
            Target joint positions (radians).
        error_tolerance : float, optional
            Allowed error tolerance (radians). Default: 0.01.
        timeout_seconds : float, optional
            Maximum time to wait (seconds). Default: 10.0.
        
        Returns
        -------
        bool
            True if target reached within tolerance before timeout, False otherwise.
        
        Notes
        -----
        This is a blocking call; it releases the Python GIL internally while waiting.
        """
CSP: ControlMode  # value = <ControlMode.CSP: 2>
CSV: ControlMode  # value = <ControlMode.CSV: 3>
DEFAULT: ArmState  # value = <ArmState.DEFAULT: 0>
E2: EEFType  # value = <EEFType.E2: 2>
G2: EEFType  # value = <EEFType.G2: 1>
GRAVITY_COMPENSATION: ArmState  # value = <ArmState.GRAVITY_COMPENSATION: 2>
INVALID: ControlMode  # value = <ControlMode.INVALID: 0>
LINEAR: PlanStrategy  # value = <PlanStrategy.LINEAR: 1>
MIT: ControlMode  # value = <ControlMode.MIT: 1>
NA: EEFType  # value = <EEFType.NA: 0>
PLANNING: ArmState  # value = <ArmState.PLANNING: 1>
PTP: PlanStrategy  # value = <PlanStrategy.PTP: 0>
PVT: ControlMode  # value = <ControlMode.PVT: 4>
RECORDING: ArmState  # value = <ArmState.RECORDING: 5>
RECORDING_HALT: ArmState  # value = <ArmState.RECORDING_HALT: 6>
RECORDING_IDLE: ArmState  # value = <ArmState.RECORDING_IDLE: 4>
REPLAYING: ArmState  # value = <ArmState.REPLAYING: 7>
REPLAYING_HALT: ArmState  # value = <ArmState.REPLAYING_HALT: 8>
RRT: PlanStrategy  # value = <PlanStrategy.RRT: 2>
