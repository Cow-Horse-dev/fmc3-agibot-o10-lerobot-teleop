import os
import ctypes
from ctypes import RTLD_GLOBAL

_here = os.path.dirname(__file__)
_lib_path = os.path.join(_here, "..", "airbot_state_machine", "lib", "libairbot_state_machine.so")
_lib_path = os.path.abspath(_lib_path)

ctypes.CDLL(_lib_path, mode=RTLD_GLOBAL)

from .airbot_state_machine import robotic_arm

__all__ = ["robotic_arm"]
