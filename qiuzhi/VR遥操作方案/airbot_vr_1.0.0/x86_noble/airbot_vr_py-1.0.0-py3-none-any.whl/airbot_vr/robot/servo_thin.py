import math
import random
import threading
import time
import typing
import numpy as np
from scipy.spatial.transform import Rotation

from mmk2_kdl_py import ArmKdlNumerical
from .lpf import OnlineVariableStepLPF
from ..utils import print_yellow, timed
from .arm_control import AirbotPlayThin


def distance(pos: np.ndarray, target: np.ndarray) -> float:
    return np.linalg.norm(pos - target)


def limit_pos(current: np.ndarray, target: np.ndarray, max_diff: float) -> np.ndarray:
    diff = target - current
    diff = np.clip(diff, -max_diff, max_diff)
    return current + diff


def limit_pose(pose: np.ndarray, target: np.ndarray, max_diff: float) -> np.ndarray:
    diff = target[:3, 3] - pose[:3, 3]
    diff = np.clip(diff, -max_diff, max_diff)
    pose[:3, 3] = pose[:3, 3] + diff
    pose[:3, :3] = target[:3, :3]
    return pose


class Arm:
    def __init__(self, eef_type, hand_id, can_port):
        self.eef_type = eef_type
        self.robot = AirbotPlayThin(self.eef_type, hand_id, can_port)
        self.robot.connect()

        if self.eef_type == "G2":
            self.arm_kdl = ArmKdlNumerical(eef_type="G2")
        else:
            self.arm_kdl = ArmKdlNumerical(eef_type="none")

        self.lpfs = [
            OnlineVariableStepLPF(fc=100, kp=10, kd=0.2, v_max=5000, a_max=100)
            for _ in range(6)
        ]

        # TODO pending parameter tuning
        if self.eef_type == "G2":
            self.eef_dist = 0.072
        elif self.eef_type == "none":
            self.eef_dist = 0.0
        else:
            self.eef_dist = [0, 0, 0, 0, 0, 0]

        self.running = threading.Event()
        self.running.set()

        # Initialize pose servoing parameters and state
        self.max_translation_step_m = 0.001
        self.max_rotation_step_rad = math.radians(3.0)
        end_pose = self.get_end_pose()
        # print(end_pose)
        self.command_pose_mat = np.array(
            [
                [1.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0],
                [0.0, 0.0, 0.0, 1.0],
            ],
            dtype=float,
        )
        self.command_pose_mat[:3, :3] = Rotation.from_quat(end_pose[1]).as_matrix()
        self.command_pose_mat[:3, 3] = end_pose[0]
        self.target_pose_mat = self.command_pose_mat.copy()

        self.position_bias = np.array([0, 0, 0], dtype=float)

        self.solve_fail = False
        self.allow_flip = False

    def __enter__(self):
        self.init()
        return self

    def init(self):
        self.t = threading.Thread(target=self.run)
        # self.t.daemon = True
        self.t.start()

    def __exit__(self, exc_type, exc_value, traceback):
        self.release()

    def get_end_pose(self):
        joints = self.robot.get_joint_pos()
        end_pose_mat = self.arm_kdl.forward_kinematics(joints)
        position = end_pose_mat[:3, 3]
        rot_matrix = end_pose_mat[:3, :3]
        quat = Rotation.from_matrix(rot_matrix).as_quat()
        return [position, quat]

    # @timed
    def update_arm(self, pose: np.ndarray):
        target_pose_mat = np.array(pose, dtype=float)
        if target_pose_mat.shape != (4, 4):
            raise ValueError("pose must be a 4x4 homogeneous transform matrix")
        # Update target and step commanded pose toward it for smooth motion
        self.target_pose_mat = target_pose_mat

        joint_pos = self.robot.get_joint_pos()
        # now = time.time()
        result = self.arm_kdl.inverse_kinematics(target_pose_mat, joint_pos)
        # print("ik cost:", time.time() - now)
        # print_yellow(f"arm_kdl result: {result}")
        if len(result) == 0:
            self.solve_fail = True
            print(f"Inverse kinematics failed. Given pose: {target_pose_mat}")
            return
        elif np.all(
            np.abs(
                np.array([joint_pos[3], joint_pos[5]]) - [result[0][3], result[0][5]]
            )
            > math.pi * 2 / 3
        ):
            print_yellow(
                f"wrist flip joint_pos: : {joint_pos[3]:.3f}, {joint_pos[5]:.3f}"
            )
            print_yellow(f"wrist flip result: {result[0][3]:.3f}, {result[0][5]:.3f}")
            if not self.allow_flip:
                self.solve_fail = True
                return
        else:
            self.solve_fail = False
        pos = result[0]
        # print_yellow(f"pos: {pos}")
        # pos = limit_pos(self.robot.get_joint_pos(), pos, math.pi / 12)
        now = time.time()
        for i in range(6):
            self.lpfs[i].update(now, pos[i])

    def update_joints(self, joints: typing.List[float]):
        now = time.time()
        for i in range(6):
            self.lpfs[i].update(now, joints[i])

    def reset(self):
        now = time.time()
        # [0, 0, 0, math.pi / 2, 0, -math.pi / 2]
        self.lpfs[0].update(now, 0)
        self.lpfs[1].update(now, 0)
        self.lpfs[2].update(now, 0)
        self.lpfs[3].update(now, math.pi / 2)
        self.lpfs[4].update(now, 0)
        self.lpfs[5].update(now, -math.pi / 2)

    def update_eef(self, eef_dist):
        if self.eef_type == "G2":
            self.eef_dist = eef_dist
        else:
            self.eef_dist = [int(x) for x in eef_dist]

    def run(self):
        while self.running.is_set():
            pos = self.robot.get_joint_pos()
            now = time.time()
            # print(now)
            for i in range(6):
                pos[i] = self.lpfs[i].sample(now)
            self.robot.servo_joint_pos(pos)
            if self.eef_type == "G2":
                self.robot.servo_eef_pos(self.eef_dist)
            time.sleep(1 / 200)

    def release(self):
        self.running.clear()
        self.t.join()
        print_yellow("start disconnect arm")
        self.robot.disconnect()


if __name__ == "__main__":
    with Arm("G2") as arm:
        start = time.time()
        pose = np.array(
            [
                [1.0, 0.0, 0.0, 0.28628],
                [0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.213],
                [0.0, 0.0, 0.0, 1.0],
            ]
        )
        while time.time() - start < 20:
            pose[1][3] = 0.05 * math.sin(time.time() - start)
            pose[2][3] = 0.213 + 0.05 * (1 - math.cos(time.time() - start))

            arm.update_arm(pose)
            arm.update_eef(0.07 * math.sin(time.time()))
            time.sleep(random.random() * 0.1)
            # time.sleep(0.1)

    print("finished")
