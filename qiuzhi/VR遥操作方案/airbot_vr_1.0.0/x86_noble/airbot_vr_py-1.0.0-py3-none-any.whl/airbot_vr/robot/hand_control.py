import time
import threading
from typing import List

import airbot_hardware_py as ah
from .eef_control import EEFController
from ..utils import print_yellow, print_red


class HandController(EEFController):
    """灵巧手控制器"""

    def __init__(self, eef_type, hand_id=1):
        try:
            self.eef_type = getattr(ah.DexterousHandTypes, eef_type)
        except AttributeError:
            print_red("ERROR: HandController eef_type getattr error")
        self.hand_id = hand_id

        self.eef = ah.create_dexterous_hand(self.hand_id, self.eef_type)
        self.hand_lock = threading.Lock()
        self.hand_target_pos = [0, 0, 0, 0, 0, 0]
        self.eef_cmd = ah.HandState()
        self.eef_cmd.positions = self.hand_target_pos
        self.eef_cmd.velocities = [1000] * 6
        self.control_thread = None
        self.running = False

    def init(self, io_context, can_port: str, hz) -> bool:
        success = self.eef.init(io_context, can_port, hz)
        # if success:
        #     self._start_control_thread()
        return success

    def enable(self) -> None:
        pass

    def disable(self) -> None:
        pass

    def configure(self) -> None:
        pass

    def get_pos(self) -> List[float]:
        """返回6元素列表"""
        self.eef.get_param("ANGLE_ACT")
        state = self.eef.state()
        current_angle = list(state.angle_act)
        return current_angle

    def servo_eef_pos(self, pos: List[float]) -> None:
        """pos 必须是长度为6的列表"""
        if len(pos) != 6:
            raise ValueError(
                f"InspirationHand requires 6 position values, got {len(pos)}"
            )
        with self.hand_lock:
            self.hand_target_pos = pos.copy()

    def _start_control_thread(self) -> None:
        """启动控制线程"""
        self.running = True
        self.control_thread = threading.Thread(target=self._control_loop, daemon=True)
        self.control_thread.start()

    def _control_loop(self) -> None:
        """控制循环（在独立线程中运行）"""
        while self.running:
            with self.hand_lock:
                target_pos = self.hand_target_pos.copy()
            self.eef_cmd.positions = target_pos
            self.eef.set_pos(self.eef_cmd)
            time.sleep(0.05)

    def stop(self) -> None:
        """停止灵巧手"""
        current_pos = self.get_pos()
        with self.hand_lock:
            self.eef_cmd.pos = current_pos
        self.eef.pvt(self.eef_cmd)

    def uninit(self) -> None:
        self.running = False
        if self.control_thread:
            self.control_thread.join(timeout=1.0)
        self.eef.uninit()
