# 如果遇到 openblas 线程数问题，可以尝试设置线程数
# import os
# os.environ['OPENBLAS_NUM_THREADS'] = '1'
# os.environ['OMP_NUM_THREADS'] = '1'
# os.environ['MKL_NUM_THREADS'] = '1'
# os.environ['BLIS_NUM_THREADS'] = '1'
# os.environ['NUMEXPR_NUM_THREADS'] = '1'

import logging
import time
import math
from functools import cached_property
import typing
from typing import Any, List
import numpy as np
import threading
from .eef_control import GripperController
from .hand_control import HandController
from ..utils import print_yellow, print_red

import airbot_hardware_py as ah

logger = logging.getLogger(__name__)


class AirbotPlayThin:
    def __init__(self, eef_type, hand_id=1, can_port="can0"):
        self.eef_type = eef_type
        self.can_port = can_port
        self.hand_id = hand_id
        # 优化：使用共享执行器减少线程数
        self.executor = ah.create_asio_executor(12)
        self.executor_hand = ah.create_asio_executor(8)
        self.io_context_arm = self.executor.get_io_context()
        self.io_context_hand = self.executor_hand.get_io_context()

        self.arm = ah.Play.create(
            ah.MotorType.OD,
            ah.MotorType.OD,
            ah.MotorType.OD,
            ah.MotorType.DM,
            ah.MotorType.DM,
            ah.MotorType.DM,
            ah.EEFType.NA,
            ah.MotorType.NA,
        )
        if self.eef_type == "G2":
            self.eef = GripperController()
        elif self.eef_type == "none":
            pass
        else:
            self.eef = HandController(self.eef_type, self.hand_id)

        self.joint_names = [
            "joint_1",
            "joint_2",
            "joint_3",
            "joint_4",
            "joint_5",
            "joint_6",
        ]
        self.eef_name = ["joint_eef"]
        self._is_connected = False

    @property
    def is_connected(self) -> bool:
        return self._is_connected

    def connect(self) -> None:
        if self.is_connected:
            raise RuntimeError(f"{self} already connected")
        if not self.arm.init(self.io_context_arm, self.can_port, 250):
            print_red(f"Failed to initialize arm on {self.can_port}")
            raise RuntimeError("Failed to initialize arm")
        time.sleep(1)
        if self.eef_type != "none":
            if not self.eef.init(self.io_context_hand, self.can_port, 250):
                print_red(f"Failed to initialize eef: {self.eef_type}")
                raise RuntimeError("Failed to initialize eef")

        self.enable_motors()
        self.configure()
        self._is_connected = True

    def enable_motors(self) -> None:
        self.arm.enable()
        time.sleep(1)
        if self.eef_type != "none":
            self.eef.enable()

    def disable_motors(self) -> None:
        self.arm.disable()
        if self.eef_type != "none":
            self.eef.disable()

    def configure(self):
        self.arm.set_param("arm.control_mode", ah.MotorControlMode.PVT)
        if self.eef_type != "none":
            self.eef.configure()

    def get_joint_pos(self):
        return self.arm.state().pos

    def get_eef_pos(self):
        return self.eef.get_pos()

    def servo_joint_pos(self, joints: typing.List[float]):
        velocities = [math.pi] * len(self.joint_names)
        eff = [8.0] * len(self.joint_names)
        return self.arm.pvt(joints, velocities, eff)

    def servo_eef_pos(self, pos):
        self.eef.servo_eef_pos(pos)

    def send_action(self, action: dict[str, Any]) -> dict[str, Any]:
        if not self.is_connected:
            raise RuntimeError(f"{self} is not connected.")

        self.servo_joint_pos(action["joints"])

        self.servo_eef_pos(action["eef"])

    def stop_all(self):
        if not self.is_connected:
            raise RuntimeError(f"{self} is not connected.")

        arm_joints = self.arm.state().pos

        velocities = [0.0] * len(self.joint_names)
        self.arm.pvt(arm_joints, velocities)
        if self.eef_type != "none":
            self.eef.stop()

        logger.warning("airbot play arms and eefs stopped immediately")

    def _safe_shutdown(self, timeout: float = 10.0):
        logger.info("Starting safe shutdown procedure...")
        self.disable_motors()
        print("start arm uninit")
        self.arm.uninit()
        if self.eef_type != "none":
            print("start eef uninit")
            self.eef.uninit()
        logger.info("Motors disabled and uninitialized")

    def disconnect(self):
        if not self.is_connected:
            raise RuntimeError(f"{self} is not connected.")
        try:
            print("_safe_shutdown")
            self._safe_shutdown()
        except Exception as e:
            logger.error(f"Safe shutdown failed: {e}")
            self.disable_motors()
            self.arm.uninit()
            if self.eef_type != "none":
                self.eef.uninit()

        self._is_connected = False
        logger.info(f"{self} safely disconnected.")


if __name__ == "__main__":
    arm = AirbotPlayThin("G2")
    arm.connect()

    now = time.time()
    action_cmd = {
        "joints": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        # "eef": [0.0],
        "eef": [0.07],
    }

    diff = np.abs(np.subtract(arm.get_joint_pos(), action_cmd["joints"]))  # 新增误差计算
    diff_eef = np.abs(np.subtract(arm.get_eef_pos(), action_cmd["eef"]))
    while (
        not np.all(diff < 1e-3) and np.all(diff_eef < 1e-3) and time.time() - now <= 10
    ):
        # while not np.all(diff < 1e-3) and time.time() - now <= 10:
        arm.send_action(action_cmd)
        diff = np.abs(np.subtract(arm.get_joint_pos(), action_cmd["joints"]))  # 新增误差计算
        diff_eef = np.abs(np.subtract(arm.get_eef_pos(), action_cmd["eef"]))
        time.sleep(0.001)

    arm.disconnect()
