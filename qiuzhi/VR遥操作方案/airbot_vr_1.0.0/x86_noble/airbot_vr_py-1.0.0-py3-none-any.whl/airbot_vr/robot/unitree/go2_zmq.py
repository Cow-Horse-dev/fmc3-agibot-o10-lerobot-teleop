import zmq
import json
import threading
import time
from airbot_vr.robot.unitree.go2_client_sdk import UnitreeGo2Client


class UnitreeGo2Zmq:
    """
    通过ZMQ协议远程控制Unitree Go2机器人的类

    提供ZMQ服务器接口，接收外部控制命令并转发给UnitreeGo2Client
    """

    def __init__(
        self, network_interface, zmq_address="tcp://localhost:8002", vis=False
    ):
        """
        初始化ZMQ服务器和机器人客户端

        Args:
            network_interface (str): 机器人网络接口名称
            zmq_address (str): ZMQ服务器绑定地址，默认tcp://localhost:8002
            vis (bool): 是否启用视频显示
        """
        # 初始化ZMQ上下文和socket
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.REP)
        self.socket.bind(zmq_address)
        print(f"ZMQ服务器已启动，绑定地址: {zmq_address}")

        # 初始化机器人客户端
        self.robot = UnitreeGo2Client(network_interface, vis=vis)
        self.running = True

        # 启动命令处理线程
        self.command_thread = threading.Thread(
            target=self._process_commands, daemon=True
        )
        self.command_thread.start()

    def _process_commands(self):
        """处理接收到的ZMQ命令"""
        print("开始处理命令...")
        try:
            while self.running:
                # 等待接收命令
                message = self.socket.recv_string()
                # print(f"收到命令: {message}")

                try:
                    # 解析JSON命令
                    command = json.loads(message)
                    response = self._execute_command(command)
                except json.JSONDecodeError:
                    response = {"status": "error", "message": "无效的JSON格式"}
                except Exception as e:
                    response = {"status": "error", "message": f"命令执行错误: {str(e)}"}

                # 发送响应
                self.socket.send_string(json.dumps(response))
        except Exception as e:
            print(f"命令处理线程错误: {str(e)}")

    def _execute_command(self, command):
        """执行解析后的命令"""
        if "action" not in command:
            return {"status": "error", "message": "命令中缺少'action'字段"}

        action = command["action"]
        params = command.get("params", {})

        # 根据动作执行相应的方法
        try:
            if action == "damp":
                self.robot.damp()
                return {"status": "success", "message": "已执行damp模式"}

            elif action == "stand_up":
                self.robot.stand_up()
                time.sleep(1)  # 等待动作完成
                return {"status": "success", "message": "已执行站立动作"}

            elif action == "stand_down":
                self.robot.stand_down()
                time.sleep(1)  # 等待动作完成
                return {"status": "success", "message": "已执行蹲下动作"}

            elif action == "move":
                x = params.get("x", 0.0)
                y = params.get("y", 0.0)
                z = params.get("z", 0.0)
                self.robot.move(x, y, z)
                return {"status": "success", "message": f"已执行移动: x={x}, y={y}, z={z}"}

            elif action == "stop_move":
                self.robot.stop_move()
                return {"status": "success", "message": "已停止移动"}

            elif action == "switch_gait":
                gait_type = params.get("gait_type", 0)
                self.robot.switch_gait(gait_type)
                return {"status": "success", "message": f"已切换步态: {gait_type}"}

            elif action == "balance_stand":
                self.robot.balance_stand()
                return {"status": "success", "message": "已执行平衡站立"}

            elif action == "recovery_stand":
                self.robot.recovery_stand()
                return {"status": "success", "message": "已执行恢复站立"}

            elif action == "flip":
                flip_type = params.get("flip_type", "left")
                result = self.robot.flip(flip_type)
                return {
                    "status": "success" if result else "error",
                    "message": f"翻转动作{'成功' if result else '失败'}",
                }

            elif action == "set_motion_mode":
                mode = params.get("mode", "walk")
                enable = params.get("enable", True)
                result = self.robot.set_motion_mode(mode, enable)
                return {
                    "status": "success" if result else "error",
                    "message": f"运动模式设置{'成功' if result else '失败'}",
                }

            elif action == "capture_image":
                filename = params.get("filename", "robot_image.jpg")
                result = self.robot.capture_image(filename)
                return {
                    "status": "success" if result else "error",
                    "message": f"图像捕获{'成功' if result else '失败'}",
                }

            elif action == "toggle_video":
                self.show_video = not self.show_video
                if self.show_video and (
                    not self.video_thread or not self.video_thread.is_alive()
                ):
                    self._start_video_thread()
                return {
                    "status": "success",
                    "message": f"视频显示已{'开启' if self.show_video else '关闭'}",
                }

            elif action == "exit":
                self.stop()
                return {"status": "success", "message": "正在退出程序"}

            else:
                return {"status": "error", "message": f"未知动作: {action}"}

        except Exception as e:
            return {"status": "error", "message": f"执行动作时出错: {str(e)}"}

    def stop(self):
        """停止服务器并清理资源"""
        self.running = False
        print("正在停止ZMQ服务器...")

        # 清理机器人资源
        self.robot.cleanup()

        # 关闭ZMQ连接
        self.socket.close()
        self.context.term()
        print("ZMQ服务器已停止")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        network_interface = sys.argv[1]
    else:
        network_interface = "wlp0s20f3"  # 默认网络接口

    # 可以通过命令行参数指定ZMQ端口，如: python unitree_go2_zmq.py eth0 5555
    zmq_port = sys.argv[2] if len(sys.argv) > 2 else "8002"
    zmq_address = f"tcp://localhost:{zmq_port}"

    try:
        # 创建并启动ZMQ控制器
        controller = UnitreeGo2Zmq(network_interface, zmq_address)

        # 保持主程序运行
        while controller.running:
            time.sleep(1)

    except KeyboardInterrupt:
        print("用户中断程序")
    except Exception as e:
        print(f"程序出错: {str(e)}")
    finally:
        if "controller" in locals():
            controller.stop()
        print("程序已退出")
