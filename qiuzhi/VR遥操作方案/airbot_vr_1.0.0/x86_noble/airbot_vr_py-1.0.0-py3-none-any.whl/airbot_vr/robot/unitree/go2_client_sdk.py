import time
import sys
import cv2
import numpy as np
from unitree_sdk2py.core.channel import ChannelFactoryInitialize
from unitree_sdk2py.go2.sport.sport_client import SportClient
from unitree_sdk2py.go2.video.video_client import VideoClient


class UnitreeGo2Client:
    """
    Unitree GO2 Robot Motion Control Client with Video Streaming

    Provides high-level motion control interfaces and video streaming for the robot
    """

    def __init__(self, network_interface, vis=True):
        """
        Initialize robot motion control and video client

        Args:
        network_interface (str): Network interface name (e.g., "eth0" or "wlan0")
        """
        # Initialize SDK communication channel
        ChannelFactoryInitialize(0, network_interface)

        # Create motion control client instance
        self.sport_client = SportClient()
        self.sport_client.SetTimeout(10.0)
        self.sport_client.Init()

        # Create video client instance
        if vis:
            self.video_client = VideoClient()
            self.video_client.SetTimeout(3.0)
            self.video_client.Init()

        print(
            f"Robot controller initialized using network interface: {network_interface}"
        )

    def damp(self):
        """Set damping mode, robot remains flexible"""
        print("Executing: Damp mode")
        self.sport_client.Damp()

    def stand_up(self):
        """Stand up action"""
        print("Executing: Stand Up")
        self.sport_client.StandUp()

    def stand_down(self):
        """Lie down action"""
        print("Executing: Stand Down")
        self.sport_client.StandDown()

    def set_body_Euler(self, yaw_rad, pitch_rad, roll_rad):

        self.sport_client.Euler(yaw_rad, pitch_rad, roll_rad)

    def move(self, x=0.0, y=0.0, z=0.0):
        """
        Control robot movement

        Args:
        x (float): Forward/backward movement speed (m/s) - positive forward
        y (float): Left/right movement speed (m/s) - positive right
        z (float): Rotation speed (rad/s) - positive counterclockwise
        """
        # print(f"Movement control: Fwd/Bwd={x}m/s, Left/Right={y}m/s, Rotation={z}rad/s")
        self.sport_client.Move(x, y, z)

    def stop_move(self):
        """Stop all movement"""
        # print("Executing: Stop Move")
        self.sport_client.StopMove()

    def switch_gait(self, gait_type=0):
        """
        Switch gait mode

        Args:
        gait_type (int):
            0 - TROT gait
            1 - Other gait
        """
        print(f"Switching gait: {'TROT' if gait_type == 0 else 'Other gait'}")
        self.sport_client.SwitchGait(gait_type)

    def balance_stand(self):
        """Balance stand mode"""
        # print("Executing: Balance Stand")
        self.sport_client.BalanceStand()

    def recovery_stand(self):
        """Recovery stand posture"""
        # print("Executing: Recovery Stand")
        self.sport_client.RecoveryStand()

    def flip(self, flip_type="left", wait_result=True):
        """
        Execute flip action

        Args:
        flip_type (str): 'left' (left flip) or 'back' (back flip)
        wait_result (bool): Whether to wait for action completion

        Returns:
        bool: Whether the action was executed successfully
        """
        print(f"Executing: {'Left Flip' if flip_type == 'left' else 'Back Flip'}")

        if flip_type == "left":
            ret = self.sport_client.LeftFlip()
        elif flip_type == "back":
            ret = self.sport_client.BackFlip()
        else:
            print("Error: Unsupported flip type")
            return False

        if wait_result:
            # Simulate waiting for action completion
            time.sleep(1.5)
            print(f"Flip action {'completed successfully' if ret == 0 else 'failed'}")

        return ret == 0

    def set_motion_mode(self, mode, enable=True):
        """
        Set specific motion mode

        Args:
        mode (str): Motion mode name
        enable (bool): Whether to enable the mode

        Returns:
        bool: Whether the operation was successful
        """
        valid_modes = [
            "walk",
            "bound",
            "avoid",
            "stair",
            "upright",
            "cross_step",
            "jump",
        ]
        command_map = {
            "walk": self.sport_client.FreeWalk,
            "bound": self.sport_client.FreeBound,
            "avoid": self.sport_client.FreeAvoid,
            "stair": self.sport_client.WalkStair,
            "upright": self.sport_client.WalkUpright,
            "cross_step": self.sport_client.CrossStep,
            "jump": self.sport_client.FreeJump,
        }

        if mode not in valid_modes:
            print(f"Error: Unsupported motion mode '{mode}'")
            return False

        # print(f"Setting motion mode: {mode} - {'Enable' if enable else 'Disable'}")
        ret = command_map[mode](enable)

        # Add special handling for certain modes
        if mode == "stair" and enable:
            # Stair climbing requires more time
            time.sleep(1)

        return ret == 0

    def get_camera_image(self):
        """
        Capture and return a single frame from the robot's camera

        Returns:
        tuple: (status_code, image_data)
                status_code: 0 if successful
                image_data: numpy image array or None if failed
        """
        code, data = self.video_client.GetImageSample()
        if code == 0:
            image_data = np.frombuffer(bytes(data), dtype=np.uint8)
            image = cv2.imdecode(image_data, cv2.IMREAD_COLOR)
            return code, image
        else:
            print(f"Error getting camera image. Code: {code}")
            return code, None

    def display_video_stream(self, window_name="front_camera", exit_key=27):
        """
        Display live video stream from robot's camera
        Press ESC or specified key to exit

        Args:
        window_name (str): Name of the display window
        exit_key (int): ASCII code of key to exit (default: 27 = ESC)
        """
        print(f"Starting video stream. Press {chr(exit_key)} to stop.")

        try:
            while True:
                code, image = self.get_camera_image()

                if code != 0:
                    print("Video stream interrupted")
                    break

                cv2.imshow(window_name, image)
                if cv2.waitKey(20) == exit_key:
                    break

        except KeyboardInterrupt:
            print("Video stream interrupted by user")

        finally:
            cv2.destroyWindow(window_name)

    def capture_image(self, filename="robot_image.jpg"):
        """
        Capture and save a single image from the camera

        Args:
        filename (str): Name of the file to save image
        """
        code, image = self.get_camera_image()
        if code == 0:
            cv2.imwrite(filename, image)
            print(f"Image saved as {filename}")
            return True
        else:
            print("Failed to capture image")
            return False

    def cleanup(self):
        """Clean up resources"""
        print("Shutting down robot controller")
        # Ensure the robot is in a safe state
        self.stop_move()
        self.stand_down()
        # Cleanup video resources
        cv2.destroyAllWindows()


if __name__ == "__main__":
    # 创建客户端实例
    # 请将 "eth0" 替换为实际使用的网络接口
    robot = UnitreeGo2Client("eth0")

    try:
        # 首先打开视频流窗口
        window_name = "Unitree GO2 实时画面"
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, 800, 600)

        # 独立显示线程
        print("正在启动视频流...按 'q' 键退出")

        # 初始状态变量
        is_standing = False  # 跟踪站立状态

        # 初始动作序列
        print("机器人正在启动...")
        # robot.damp()
        time.sleep(2)
        angle_step = 0.05
        body_yaw = 0.0
        body_pitch = 0.0
        body_roll = 0.0
        # 主循环：运动控制与视频显示
        while True:
            # 获取并显示图像帧
            code, frame = robot.get_camera_image()
            if code == 0 and frame is not None:
                cv2.imshow(window_name, frame)

            # 检测按键输入
            key = cv2.waitKey(10)
            if key == ord("q") or key == 27:  # 27是ESC键
                print("退出程序...")
                break

            # 空格键切换站立/蹲下
            elif key == 32:  # 32是空格键的ASCII码
                if not is_standing:
                    print("机器人正在站立...")
                    robot.stand_up()
                    robot.switch_gait(0)
                    is_standing = True
                    time.sleep(1)  # 短暂等待动作执行
                    print("机器人站立完成")
                else:
                    print("机器人正在蹲下...")
                    robot.stand_down()
                    is_standing = False
                    time.sleep(1)  # 短暂等待动作执行
                    print("机器人蹲下完成")

            # 运动控制序列
            elif key == ord("w") and is_standing:  # 前进
                print("前进")
                robot.move(x=0.3)
            elif key == ord("s") and is_standing:  # 后退
                print("后退")
                robot.move(x=-0.3)
            elif key == ord("a") and is_standing:  # 左移
                print("左移")
                robot.move(y=0.3)
            elif key == ord("d") and is_standing:  # 右移
                print("右移")
                robot.move(y=-0.3)
            elif key == ord("r") and is_standing:  # 左转
                print("左转")
                robot.move(z=1.0)
            elif key == ord("t") and is_standing:  # 右转
                print("右转")
                robot.move(z=-1.0)
            # 身体姿态控制 - 俯仰（Pitch）
            elif key == ord("i") and is_standing:  # 增加俯仰角（前倾）
                body_pitch += angle_step
                print(f"增加俯仰角: {body_pitch:.2f} rad")
                robot.set_body_Euler(body_yaw, body_pitch, body_roll)
            elif key == ord("k") and is_standing:  # 减少俯仰角（后倾）
                body_pitch -= angle_step
                print(f"减少俯仰角: {body_pitch:.2f} rad")
                robot.set_body_Euler(body_yaw, body_pitch, body_roll)

            # 身体姿态控制 - 横滚（Roll）
            elif key == ord("j") and is_standing:  # 增加横滚角（左倾）
                body_roll += angle_step
                print(f"增加横滚角: {body_roll:.2f} rad")
                robot.set_body_Euler(body_yaw, body_pitch, body_roll)
            elif key == ord("l") and is_standing:  # 减少横滚角（右倾）
                body_roll -= angle_step
                print(f"减少横滚角: {body_roll:.2f} rad")
                robot.set_body_Euler(body_yaw, body_pitch, body_roll)

            # 身体姿态控制 - 偏航（Yaw）
            elif key == ord("u") and is_standing:  # 增加偏航角（左转）
                body_yaw += angle_step
                print(f"增加偏航角: {body_yaw:.2f} rad")
                robot.set_body_Euler(body_yaw, body_pitch, body_roll)
            elif key == ord("o") and is_standing:  # 减少偏航角（右转）
                body_yaw -= angle_step
                print(f"减少偏航角: {body_yaw:.2f} rad")
                robot.set_body_Euler(body_yaw, body_pitch, body_roll)

            # 重置身体姿态
            elif key == ord("0") and is_standing:  # 重置姿态
                body_yaw = 0.0
                body_pitch = 0.0
                body_roll = 0.0
                print("重置身体姿态")
                robot.set_body_Euler(body_yaw, body_pitch, body_roll)
            else:
                if is_standing:  # 只在站立状态下执行停止
                    robot.stop_move()

        # 程序退出时恢复安全状态
        if is_standing:
            print("机器人即将躺下...")
            robot.stand_down()
            time.sleep(2)

    except Exception as e:
        print(f"程序出错: {str(e)}")

    finally:
        # 确保清理资源
        robot.cleanup()
        cv2.destroyAllWindows()
        print("资源清理完成")
