import logging
import time
import math
import threading
from abc import ABC, abstractmethod
from functools import cached_property
import typing
from typing import Any, List
import numpy as np
from typing import Any

import airbot_hardware_py as ah

logger = logging.getLogger(__name__)


# ============= 抽象基类：定义 EEF 接口 =============
class EEFController(ABC):
    """End Effector 控制器的抽象基类"""

    eef: Any
    eef_cmd: Any

    @abstractmethod
    def init(self, io_context, can_port: str, hz) -> bool:
        """初始化 EEF"""
        pass

    @abstractmethod
    def enable(self) -> None:
        """使能 EEF"""
        pass

    @abstractmethod
    def disable(self) -> None:
        """禁用 EEF"""
        pass

    @abstractmethod
    def configure(self) -> None:
        """配置 EEF 参数"""
        pass

    @abstractmethod
    def get_pos(self) -> List[float]:
        """获取当前位置（统一返回列表格式）"""
        pass

    @abstractmethod
    def servo_eef_pos(self, pos: Any) -> None:
        """控制 EEF 到目标位置"""
        pass

    @abstractmethod
    def stop(self) -> None:
        """停止 EEF"""
        pass

    @abstractmethod
    def uninit(self) -> None:
        """反初始化"""
        pass


# ============= Gripper 控制器 =============
class GripperController(EEFController):
    """夹爪控制器"""

    def __init__(self):
        self.eef = ah.EEF1.create(ah.EEFType.G2, ah.MotorType.DM)
        self.eef_cmd = ah.EEFCommand1()
        self.eef_cmd.pos = [0.0]
        self.eef_cmd.vel = [10.0]
        self.eef_cmd.current_threshold = [5.0]

    def init(self, io_context, can_port: str, hz) -> bool:
        success = self.eef.init(io_context, can_port, hz)
        return success

    def enable(self) -> None:
        self.eef.enable()

    def disable(self) -> None:
        self.eef.disable()

    def configure(self) -> None:
        self.eef.set_param("control_mode", ah.ParamValue(ah.ParamType.UINT32_LE, 4))

    def get_pos(self) -> List[float]:
        """返回单元素列表，保持接口统一"""
        return self.eef.state().pos

    def servo_eef_pos(self, pos: Any) -> None:
        """pos 可以是单个值或列表"""
        if isinstance(pos, list):
            pos_value = pos[0]
        else:
            pos_value = pos
        self.eef_cmd.pos = [pos_value]
        self.eef.pvt(self.eef_cmd)

    def stop(self) -> None:
        eef_state = self.eef.state()
        self.eef_cmd.pos = eef_state.pos
        self.eef.pvt(self.eef_cmd)

    def uninit(self) -> None:
        self.eef.uninit()
