from sensor_msgs.msg import Joy
from tf2_msgs.msg import TFMessage
from scipy.spatial.transform import Rotation
import numpy as np
from std_msgs.msg import Float32MultiArray


class PicoVRTeleopRos2:
    def __init__(self, eef_type="G2"):
        self.vr_ctrl_data = {
            "A": False,
            "B": False,
            "RThU": False,  # 右手柄主触摸板触摸
            "RJ": False,  # 右手柄主触摸板按压
            "RG": False,  # 右手柄抓握键
            "RTr": False,  # 右手柄扳机键
            "X": False,
            "Y": False,
            "LThU": False,  # 左手柄主触摸板触摸
            "LJ": False,  # 左手柄主触摸板按压
            "LG": False,  # 左手柄抓握键
            "LTr": False,  # 左手柄扳机键
            "leftJS": {
                "ud": 0.0,
                "lr": 0.0,
            },  # 左手柄主触摸板推压程度 ud为上下，lr为左右，ud推压至下极限为-1，推压至上极限为1; lr推压至左极限为-1，推压至右极限为1
            "leftTrig": 0.0,  # 左手柄扳机键按压程度
            "leftGrip": 0.0,  # 左手柄抓握键按压程度
            "rightJS": {
                "ud": 0.0,
                "lr": 0.0,
            },  # 右手柄主触摸板 ud为上下，lr为左右，ud推压至下极限为-1，推压至上极限为1; lr推压至左极限为-1，推压至右极限为1
            "rightTrig": 0.0,  # 右手柄扳机键按压程度
            "rightGrip": 0.0,  # 右手柄抓握键按压程度
        }
        self.eef_type = eef_type

        self.vrCmdRecv = False
        self.headInfoRecv = False
        self.leftInfoRecv = False
        self.rightInfoRecv = False

        self.head_info = Float32MultiArray()
        self.head_info.data = [0.0] * 7
        self.left_info = Float32MultiArray()
        self.left_info.data = [0.0] * 7
        self.right_info = Float32MultiArray()
        self.right_info.data = [0.0] * 7

    def joy_callback(self, msg):
        joy_state = msg
        self.vr_ctrl_data["A"] = joy_state.buttons[17] == 1
        self.vr_ctrl_data["B"] = joy_state.buttons[18] == 1
        self.vr_ctrl_data["RThU"] = joy_state.buttons[27] == 1
        self.vr_ctrl_data["RJ"] = joy_state.buttons[26] == 1
        self.vr_ctrl_data["RG"] = joy_state.buttons[19] == 1
        self.vr_ctrl_data["RTr"] = joy_state.buttons[20] == 1
        self.vr_ctrl_data["X"] = joy_state.buttons[4] == 1
        self.vr_ctrl_data["Y"] = joy_state.buttons[5] == 1
        self.vr_ctrl_data["LThU"] = joy_state.buttons[14] == 1
        self.vr_ctrl_data["LJ"] = joy_state.buttons[13] == 1
        self.vr_ctrl_data["LG"] = joy_state.buttons[6] == 1
        self.vr_ctrl_data["LTr"] = joy_state.buttons[7] == 1
        self.vr_ctrl_data["leftJS"]["ud"] = joy_state.axes[5]
        self.vr_ctrl_data["leftJS"]["lr"] = joy_state.axes[4]
        self.vr_ctrl_data["leftTrig"] = joy_state.axes[3]
        self.vr_ctrl_data["leftGrip"] = joy_state.axes[2]
        self.vr_ctrl_data["rightJS"]["ud"] = joy_state.axes[10]
        self.vr_ctrl_data["rightJS"]["lr"] = joy_state.axes[9]
        self.vr_ctrl_data["rightTrig"] = joy_state.axes[8]
        self.vr_ctrl_data["rightGrip"] = joy_state.axes[7]
        self.vrCmdRecv = True

    def pose_callback(self, msg: TFMessage):
        for transform in msg.transforms:
            frame_id = transform.child_frame_id

            if frame_id == "hmd":
                self.head_info.data[0] = transform.transform.translation.x
                self.head_info.data[1] = transform.transform.translation.y
                self.head_info.data[2] = transform.transform.translation.z
                self.head_info.data[3] = transform.transform.rotation.x
                self.head_info.data[4] = transform.transform.rotation.y
                self.head_info.data[5] = transform.transform.rotation.z
                self.head_info.data[6] = transform.transform.rotation.w
                self.headInfoRecv = True
            elif frame_id == "left_controller":
                if self.eef_type == "G2" or self.eef_type == "ins_hand":
                    self.left_info.data[0] = transform.transform.translation.x
                    self.left_info.data[1] = transform.transform.translation.y
                    self.left_info.data[2] = transform.transform.translation.z
                    self.left_info.data[3] = transform.transform.rotation.x
                    self.left_info.data[4] = transform.transform.rotation.y
                    self.left_info.data[5] = transform.transform.rotation.z
                    self.left_info.data[6] = transform.transform.rotation.w
                    self.leftInfoRecv = True
            elif frame_id == "right_controller":
                if self.eef_type == "G2" or self.eef_type == "ins_hand":
                    self.right_info.data[0] = transform.transform.translation.x
                    self.right_info.data[1] = transform.transform.translation.y
                    self.right_info.data[2] = transform.transform.translation.z
                    self.right_info.data[3] = transform.transform.rotation.x
                    self.right_info.data[4] = transform.transform.rotation.y
                    self.right_info.data[5] = transform.transform.rotation.z
                    self.right_info.data[6] = transform.transform.rotation.w
                    self.rightInfoRecv = True
        # print("Head Info:",self.head_info.data[:3])

    def wrist_pose_callback(self, msg: TFMessage):
        if self.eef_type == "hand":
            for transform in msg.transforms:
                frame_id = transform.child_frame_id
                if frame_id == "left_wrist":
                    trans = [
                        transform.transform.translation.x,
                        transform.transform.translation.y,
                        transform.transform.translation.z,
                    ]
                    quat = [
                        transform.transform.rotation.x,
                        transform.transform.rotation.y,
                        transform.transform.rotation.z,
                        transform.transform.rotation.w,
                    ]
                    vr_trans, vr_quat = CoordinateCalibration.calibrate(trans, quat)
                    self.left_info.data = [*vr_trans, *vr_quat]
                    self.leftInfoRecv = True

                elif frame_id == "right_wrist":
                    trans = [
                        transform.transform.translation.x,
                        transform.transform.translation.y,
                        transform.transform.translation.z,
                    ]
                    quat = [
                        transform.transform.rotation.x,
                        transform.transform.rotation.y,
                        transform.transform.rotation.z,
                        transform.transform.rotation.w,
                    ]
                    vr_trans, vr_quat = CoordinateCalibration.calibrate(trans, quat)
                    self.right_info.data = [*vr_trans, *vr_quat]
                    self.rightInfoRecv = True

            # print("Left Wrist Info:",self.left_info.data[:3])
            # print("Right Wrist Info:",self.right_info.data[:3])


class CoordinateCalibration:
    def calibrate(position, rotation):
        """
        对 position 和 rotation 施加一个绕动坐标系的坐标变换。
        该变换顺序为：先绕新坐标系的y轴旋转90度，再绕最新的z轴旋转180度。
        """
        rot_input = Rotation.from_quat(rotation)
        rot_y = Rotation.from_euler("y", 90, degrees=True)
        rot_z = Rotation.from_euler("z", 180, degrees=True)
        rot_total = rot_y * rot_z

        # 新旋转
        new_rot = rot_input * rot_total
        new_rotation = new_rot.as_quat().tolist()

        # 新位置
        new_position = position

        return new_position, new_rotation


if __name__ == "__main__":
    # pico_info = PicoVRTeleopRos2()
    # pico_info.init_sub()
    import rclpy

    rclpy.init()
    pico_info = PicoVRTeleopRos2()
    pico_info.init_sub()
    rclpy.spin(pico_info)
    rclpy.shutdown()
