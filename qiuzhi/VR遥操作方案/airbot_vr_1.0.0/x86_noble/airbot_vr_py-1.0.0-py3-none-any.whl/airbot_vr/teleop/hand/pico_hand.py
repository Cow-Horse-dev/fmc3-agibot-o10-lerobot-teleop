"""
Pico VR手部遥操作器适配器

将现有的Pico VR手部控制逻辑适配为手部遥操作器接口。
"""

from typing import List
from .base_hand import BaseHandTeleoperator


class PicoHandTeleoperator(BaseHandTeleoperator):
    """Pico VR手部遥操作器适配器"""

    def __init__(self, pico_teleop):
        super().__init__()
        self.pico_teleop = pico_teleop
        self.is_connected = True  # Pico通过VR系统连接
        self.is_hand_joint_ctrl_mode = True  # 默认控制模式为手关节控制模式
        self.hand_control_threshold = [
            [0, 1000],
            [0, 1000],
            [0, 1000],
            [0, 1000],
            [0, 1000],
            [0, 1000],
        ]

    def init(self) -> bool:
        """初始化Pico手部控制"""
        if self.pico_teleop is None:
            print("错误: Pico遥操作对象未提供")
            return False

        self.is_connected = True
        print("Pico VR手部控制初始化成功")
        return True

    def start_listening(self) -> None:
        """开始监听Pico手部数据"""
        self.is_running = True
        print("Pico VR手部数据监听已启动")

    def stop(self) -> None:
        """停止监听"""
        self.is_running = False
        print("Pico VR手部控制已停止")

    def get_hand_data(self) -> List[float]:
        """从Pico VR数据中提取手部控制数据

        Returns:
            List[float]: 6个关节的角度数据
        """
        if not self.is_running or not self.is_connected:
            return [0] * 6

        # 根据现有的Pico控制逻辑提取手部数据
        if hasattr(self.pico_teleop, "vr_ctrl_data"):
            # 检查是否在扳机控制模式下
            if self.pico_teleop.vr_ctrl_data.get("LTr", False):
                if self.is_hand_joint_ctrl_mode:
                    # 关节控制模式
                    hand_control_value = [
                        self.pico_teleop.vr_ctrl_data.get("rightJS", {}).get("ud", 0.0),
                        self.pico_teleop.vr_ctrl_data.get("leftJS", {}).get("lr", 0.0),
                        self.pico_teleop.vr_ctrl_data.get("rightJS", {}).get("lr", 0.0),
                        self.pico_teleop.vr_ctrl_data.get("rightJS", {}).get("lr", 0.0),
                        self.pico_teleop.vr_ctrl_data.get("rightJS", {}).get("lr", 0.0),
                        self.pico_teleop.vr_ctrl_data.get("rightJS", {}).get("lr", 0.0),
                    ]

                    # 更新手部控制数据
                    for i in range(6):
                        self.hand_data[i] = self._update_hand_pose(
                            i, hand_control_value[i], self.hand_control_threshold[i]
                        )
                else:
                    # 手势控制模式
                    left_js = self.pico_teleop.vr_ctrl_data.get("leftJS", {})
                    if left_js.get("ud", 0.0) > 0.9:  # ok
                        self.hand_data = [1000, 550, 520, 130, 50, 0]
                    elif left_js.get("lr", 0.0) > 0.9:  # 点赞
                        self.hand_data = [0, 0, 1000, 1000, 1000, 1000]
                    elif left_js.get("ud", 0.0) < -0.9:  # 比yeah
                        self.hand_data = [1000, 1000, 0, 0, 1000, 1000]
                    elif left_js.get("lr", 0.0) < -0.9:  # 比6
                        self.hand_data = [0, 0, 1000, 1000, 1000, 0]

        return self.hand_data.copy()

    def _update_hand_pose(
        self, i: int, control_value: float, control_threshold: List[int]
    ) -> int:
        """更新手部姿态

        Args:
            i: 关节索引
            control_value: 控制值
            control_threshold: 控制阈值

        Returns:
            int: 更新后的关节值
        """
        threshold = 0.7
        step_size = 15
        cur_hand_pose = self.hand_data[i]

        if control_value > threshold:
            return min(control_threshold[1], cur_hand_pose + step_size)
        elif control_value < -threshold:
            return max(control_threshold[0], cur_hand_pose - step_size)
        else:
            return cur_hand_pose

    def set_hand_joint_ctrl_mode(self, is_joint_mode: bool) -> None:
        """设置手部控制模式

        Args:
            is_joint_mode: True为关节控制模式，False为手势控制模式
        """
        self.is_hand_joint_ctrl_mode = is_joint_mode
        mode = "手关节控制模式" if is_joint_mode else "手势控制模式"
        print(f"Pico手部控制切换为{mode}")

    def get_device_info(self) -> dict:
        """获取设备信息"""
        info = super().get_device_info()
        info.update(
            {
                "control_mode": "joint" if self.is_hand_joint_ctrl_mode else "gesture",
                "pico_teleop_available": self.pico_teleop is not None,
            }
        )
        return info
