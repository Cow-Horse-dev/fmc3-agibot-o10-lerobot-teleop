import tkinter as tk
from tkinter import ttk
import time
from datetime import datetime

UPDATE_INTERVAL = 1 / 250


class VRStatusGUI:
    """VR状态可视化界面"""

    def __init__(self, vr_arm_node):
        self.vr_arm = vr_arm_node
        self.root = tk.Tk()
        self.root.title("VR控制状态监控")
        self.root.geometry(
            "1400x900"
        )  # Increased window size for wrist tracker display
        self.root.configure(bg="#f0f0f0")

        # --- Centralized Font Definitions ---
        self.title_font = ("Arial", 22, "bold")
        self.header_font = ("Arial", 16, "bold")
        self.label_font_bold = ("Arial", 14, "bold")
        self.label_font = ("Arial", 14)
        self.small_label_font = ("Arial", 12)

        # --- Style for ttk Widgets (like Treeview) ---
        style = ttk.Style()
        style.configure("Treeview.Heading", font=("Arial", 14, "bold"))
        style.configure(
            "Treeview", font=("Arial", 12), rowheight=30
        )  # Increase row height

        # 创建界面
        self.create_widgets()

        # 启动定时更新
        self.update_display()

    def create_widgets(self):
        """创建界面组件"""
        # 主标题
        title_label = tk.Label(
            self.root, text="VR控制系统状态监控", font=self.title_font, bg="#f0f0f0", fg="#333"
        )
        title_label.pack(pady=10)  # Add some padding for the main title

        # 创建主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        # 左侧框架 - VR控制器状态
        left_frame = ttk.LabelFrame(
            main_frame,
            text="VR控制器状态",
            labelwidget=tk.Label(main_frame, text="VR控制器状态", font=self.header_font),
            padding=15,
        )
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        # 右侧框架 - 网络状态
        right_frame = ttk.LabelFrame(
            main_frame,
            text="网络连接状态",
            labelwidget=tk.Label(main_frame, text="网络连接状态", font=self.header_font),
            padding=15,
        )
        right_frame.grid(row=0, column=1, sticky="nsew", padx=(10, 0))

        # 底部框架 - 连接客户端信息
        bottom_frame = ttk.LabelFrame(
            main_frame,
            text="连接客户端信息",
            labelwidget=tk.Label(main_frame, text="连接客户端信息", font=self.header_font),
            padding=15,
        )
        bottom_frame.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(10, 0))

        # 配置网格权重
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)

        config_frame = ttk.LabelFrame(
            self.root,
            text="设备配置信息",
            labelwidget=tk.Label(self.root, text="设备配置信息", font=self.header_font),
            padding=10,
        )
        config_frame.pack(fill=tk.X, expand=False, padx=20, pady=5)
        self.create_config_widgets(config_frame)

        # 创建VR控制器状态显示
        self.create_vr_status_widgets(left_frame)

        # 创建网络状态显示
        self.create_network_status_widgets(right_frame)

        # 创建客户端连接信息显示
        self.create_client_info_widgets(bottom_frame)

    def create_config_widgets(self, parent):
        """创建设备配置信息显示组件"""
        # VR设备类型
        tk.Label(parent, text="VR设备类型:", font=self.label_font_bold).grid(
            row=0, column=0, sticky="w", pady=5
        )
        vr_device = getattr(self.vr_arm, "vr_device", "unknown")
        vr_device_display = {
            "quest": "Quest ROS",
            "pico": "PICO ROS",
            "pico_webrtc": "PICO WebRTC",
        }.get(vr_device, vr_device)
        self.vr_device_var = tk.StringVar(value=vr_device_display)
        tk.Label(
            parent, textvariable=self.vr_device_var, font=self.label_font, fg="blue"
        ).grid(row=0, column=1, sticky="w", padx=(10, 0), pady=5)

        # 末端执行器类型
        tk.Label(parent, text="末端执行器:", font=self.label_font_bold).grid(
            row=0, column=2, sticky="w", padx=(30, 0), pady=5
        )
        eef_type = getattr(self.vr_arm, "eef_type", "unknown")
        eef_type_display = {"G2": "夹爪", "hand": "灵巧手"}.get(eef_type, eef_type)
        self.eef_type_var = tk.StringVar(value=eef_type_display)
        tk.Label(
            parent, textvariable=self.eef_type_var, font=self.label_font, fg="green"
        ).grid(row=0, column=3, sticky="w", padx=(10, 0), pady=5)

        # 机械臂SDK类型
        tk.Label(parent, text="机械臂SDK:", font=self.label_font_bold).grid(
            row=0, column=4, sticky="w", padx=(30, 0), pady=5
        )
        arm_sdk_type = getattr(self.vr_arm, "arm_sdk_type", "unknown")
        arm_sdk_display = {"thin": "thin", "full": "full"}.get(
            arm_sdk_type, arm_sdk_type
        )
        self.arm_sdk_var = tk.StringVar(value=arm_sdk_display)
        tk.Label(
            parent, textvariable=self.arm_sdk_var, font=self.label_font, fg="purple"
        ).grid(row=0, column=5, sticky="w", padx=(10, 0), pady=5)

    def create_vr_status_widgets(self, parent):
        """创建VR控制器状态显示组件"""
        # 头显电量
        tk.Label(parent, text="头显电量:", font=self.label_font_bold).grid(
            row=0, column=0, sticky="w", pady=5
        )
        self.hmd_battery_var = tk.StringVar(value="0.0%")
        self.hmd_battery_label = tk.Label(
            parent, textvariable=self.hmd_battery_var, font=self.label_font, fg="blue"
        )
        self.hmd_battery_label.grid(row=0, column=1, sticky="w", padx=(10, 0), pady=5)

        # 右控制器状态
        tk.Label(parent, text="右控制器:", font=self.label_font_bold).grid(
            row=1, column=0, sticky="w", pady=5
        )

        # 右控制器追踪状态
        tk.Label(parent, text="  追踪状态:", font=self.small_label_font).grid(
            row=2, column=0, sticky="w", padx=(20, 0), pady=2
        )
        self.right_tracked_var = tk.StringVar(value="未追踪")
        self.right_tracked_label = tk.Label(
            parent, textvariable=self.right_tracked_var, font=self.small_label_font
        )
        self.right_tracked_label.grid(row=2, column=1, sticky="w", padx=(10, 0), pady=2)

        # 右控制器电量
        tk.Label(parent, text="  电量:", font=self.small_label_font).grid(
            row=3, column=0, sticky="w", padx=(20, 0), pady=2
        )
        self.right_battery_var = tk.StringVar(value="0.0%")
        self.right_battery_label = tk.Label(
            parent,
            textvariable=self.right_battery_var,
            font=self.small_label_font,
            fg="blue",
        )
        self.right_battery_label.grid(row=3, column=1, sticky="w", padx=(10, 0), pady=2)

        # 左控制器状态
        tk.Label(parent, text="左控制器:", font=self.label_font_bold).grid(
            row=4, column=0, sticky="w", pady=5
        )

        # 左控制器追踪状态
        tk.Label(parent, text="  追踪状态:", font=self.small_label_font).grid(
            row=5, column=0, sticky="w", padx=(20, 0), pady=2
        )
        self.left_tracked_var = tk.StringVar(value="未追踪")
        self.left_tracked_label = tk.Label(
            parent, textvariable=self.left_tracked_var, font=self.small_label_font
        )
        self.left_tracked_label.grid(row=5, column=1, sticky="w", padx=(10, 0), pady=2)

        # 左控制器电量
        tk.Label(parent, text="  电量:", font=self.small_label_font).grid(
            row=6, column=0, sticky="w", padx=(20, 0), pady=2
        )
        self.left_battery_var = tk.StringVar(value="0.0%")
        self.left_battery_label = tk.Label(
            parent,
            textvariable=self.left_battery_var,
            font=self.small_label_font,
            fg="blue",
        )
        self.left_battery_label.grid(row=6, column=1, sticky="w", padx=(10, 0), pady=2)

        # 腕带追踪器状态
        tk.Label(parent, text="腕带追踪器:", font=self.label_font_bold).grid(
            row=7, column=0, sticky="w", pady=(10, 5)
        )

        # 左腕带追踪状态
        tk.Label(parent, text="  左腕带追踪:", font=self.small_label_font).grid(
            row=8, column=0, sticky="w", padx=(20, 0), pady=2
        )
        self.left_wrist_tracked_var = tk.StringVar(value="未追踪")
        self.left_wrist_tracked_label = tk.Label(
            parent, textvariable=self.left_wrist_tracked_var, font=self.small_label_font
        )
        self.left_wrist_tracked_label.grid(
            row=8, column=1, sticky="w", padx=(10, 0), pady=2
        )

        # 左腕带电量
        tk.Label(parent, text="  左腕带电量:", font=self.small_label_font).grid(
            row=9, column=0, sticky="w", padx=(20, 0), pady=2
        )
        self.left_wrist_battery_var = tk.StringVar(value="0.0%")
        self.left_wrist_battery_label = tk.Label(
            parent,
            textvariable=self.left_wrist_battery_var,
            font=self.small_label_font,
            fg="orange",
        )
        self.left_wrist_battery_label.grid(
            row=9, column=1, sticky="w", padx=(10, 0), pady=2
        )

        # 右腕带追踪状态
        tk.Label(parent, text="  右腕带追踪:", font=self.small_label_font).grid(
            row=10, column=0, sticky="w", padx=(20, 0), pady=2
        )
        self.right_wrist_tracked_var = tk.StringVar(value="未追踪")
        self.right_wrist_tracked_label = tk.Label(
            parent,
            textvariable=self.right_wrist_tracked_var,
            font=self.small_label_font,
        )
        self.right_wrist_tracked_label.grid(
            row=10, column=1, sticky="w", padx=(10, 0), pady=2
        )

        # 右腕带电量
        tk.Label(parent, text="  右腕带电量:", font=self.small_label_font).grid(
            row=11, column=0, sticky="w", padx=(20, 0), pady=2
        )
        self.right_wrist_battery_var = tk.StringVar(value="0.0%")
        self.right_wrist_battery_label = tk.Label(
            parent,
            textvariable=self.right_wrist_battery_var,
            font=self.small_label_font,
            fg="orange",
        )
        self.right_wrist_battery_label.grid(
            row=11, column=1, sticky="w", padx=(10, 0), pady=2
        )

    def create_network_status_widgets(self, parent):
        """创建网络状态显示组件"""
        # 连接状态
        tk.Label(parent, text="连接状态:", font=self.label_font_bold).grid(
            row=4, column=0, sticky="w", pady=5
        )
        self.connection_var = tk.StringVar(value="未连接")
        self.connection_label = tk.Label(
            parent, textvariable=self.connection_var, font=self.label_font_bold
        )
        self.connection_label.grid(row=4, column=1, sticky="w", padx=(10, 0), pady=5)

    def create_client_info_widgets(self, parent):
        """创建客户端连接信息显示组件"""
        columns = ("客户端ID", "连接时间", "状态", "连接时长")
        self.client_tree = ttk.Treeview(
            parent, columns=columns, show="headings", height=6
        )

        for col in columns:
            self.client_tree.heading(col, text=col)
            self.client_tree.column(col, width=180, anchor="center")

        scrollbar = ttk.Scrollbar(
            parent, orient=tk.VERTICAL, command=self.client_tree.yview
        )
        self.client_tree.configure(yscrollcommand=scrollbar.set)

        self.client_tree.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        scrollbar.grid(row=0, column=1, sticky="ns")

        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(0, weight=1)

        stats_frame = ttk.Frame(parent)
        stats_frame.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(10, 0))

        tk.Label(stats_frame, text="总连接数:", font=self.label_font_bold).grid(
            row=0, column=0, sticky="w"
        )
        self.total_connections_var = tk.StringVar(value="0")
        tk.Label(
            stats_frame,
            textvariable=self.total_connections_var,
            font=self.label_font,
            fg="green",
        ).grid(row=0, column=1, sticky="w", padx=(10, 0))

        tk.Label(stats_frame, text="当前连接数:", font=self.label_font_bold).grid(
            row=0, column=2, sticky="w", padx=(20, 0)
        )
        self.current_connections_var = tk.StringVar(value="0")
        tk.Label(
            stats_frame,
            textvariable=self.current_connections_var,
            font=self.label_font,
            fg="blue",
        ).grid(row=0, column=3, sticky="w", padx=(10, 0))

    def update_display(self):
        """更新显示内容"""
        try:
            if hasattr(self.vr_arm, "vr_device"):
                vr_device = self.vr_arm.vr_device
                vr_device_display = {
                    "quest": "Quest ROS",
                    "pico": "PICO ROS",
                    "pico_webrtc": "Pico WebRTC",
                }.get(vr_device, vr_device)
                self.vr_device_var.set(vr_device_display)

            if hasattr(self.vr_arm, "eef_type"):
                eef_type = self.vr_arm.eef_type
                eef_display = {"gripper": "夹爪", "hand": "灵巧手"}.get(eef_type, eef_type)
                self.eef_type_var.set(eef_display)

            if hasattr(self.vr_arm, "arm_sdk_type"):
                arm_sdk_type = self.vr_arm.arm_sdk_type
                arm_sdk_display = {"thin": "thin", "full": "full"}.get(
                    arm_sdk_type, arm_sdk_type
                )
                self.arm_sdk_var.set(arm_sdk_display)

            if hasattr(self.vr_arm, "vr_teleop") and hasattr(
                self.vr_arm, "vr_ctrl_state"
            ):
                ctrl_state = self.vr_arm.vr_ctrl_state

                hmd_battery = ctrl_state.get("HBattery", 0.0)
                self.hmd_battery_var.set(f"{hmd_battery:.1f}%")

                right_tracked = ctrl_state.get("RIsTracked", False)
                self.right_tracked_var.set("正在追踪" if right_tracked else "未追踪")
                self.right_tracked_label.config(fg="green" if right_tracked else "red")

                right_battery = ctrl_state.get("RBattery", 0.0)
                self.right_battery_var.set(f"{right_battery:.1f}%")

                left_tracked = ctrl_state.get("LIsTracked", False)
                self.left_tracked_var.set("正在追踪" if left_tracked else "未追踪")
                self.left_tracked_label.config(fg="green" if left_tracked else "red")

                left_battery = ctrl_state.get("LBattery", 0.0)
                self.left_battery_var.set(f"{left_battery:.1f}%")

                # 腕带追踪器状态更新
                left_wrist_tracked = ctrl_state.get("LWristTracked", False)
                self.left_wrist_tracked_var.set("正在追踪" if left_wrist_tracked else "未追踪")
                self.left_wrist_tracked_label.config(
                    fg="green" if left_wrist_tracked else "red"
                )

                left_wrist_battery = ctrl_state.get("LWristBattery", 0.0)
                self.left_wrist_battery_var.set(f"{left_wrist_battery:.1f}%")

                right_wrist_tracked = ctrl_state.get("RWristTracked", False)
                self.right_wrist_tracked_var.set(
                    "正在追踪" if right_wrist_tracked else "未追踪"
                )
                self.right_wrist_tracked_label.config(
                    fg="green" if right_wrist_tracked else "red"
                )

                right_wrist_battery = ctrl_state.get("RWristBattery", 0.0)
                self.right_wrist_battery_var.set(f"{right_wrist_battery:.1f}%")

            if hasattr(self.vr_arm, "vr_teleop") and hasattr(
                self.vr_arm, "connection_status"
            ):
                conn_status = self.vr_arm.connection_status

                is_connected = conn_status.get("is_connected", False)
                self.connection_var.set("已连接" if is_connected else "未连接")
                self.connection_label.config(fg="green" if is_connected else "red")

                for item in self.client_tree.get_children():
                    self.client_tree.delete(item)

                connected_clients = conn_status.get("connected_clients", {})
                current_time = time.time()

                for pc_id, client_info in connected_clients.items():
                    connect_time = client_info.get("connect_time", 0)
                    status = client_info.get("status", "unknown")

                    connect_time_str = datetime.fromtimestamp(connect_time).strftime(
                        "%H:%M:%S"
                    )

                    duration = current_time - connect_time
                    duration_str = f"{int(duration//3600):02d}:{int((duration%3600)//60):02d}:{int(duration%60):02d}"

                    self.client_tree.insert(
                        "",
                        "end",
                        values=(
                            pc_id[:20] + "..." if len(pc_id) > 20 else pc_id,
                            connect_time_str,
                            status,
                            duration_str,
                        ),
                    )

                total_connections = conn_status.get("total_connections", 0)
                self.total_connections_var.set(str(total_connections))

                current_connections = len(connected_clients)
                self.current_connections_var.set(str(current_connections))

        except Exception as e:
            print(f"GUI更新错误: {e}")

        self.root.after(500, self.update_display)

    def run(self):
        """运行GUI"""
        self.root.mainloop()

    def destroy(self):
        """销毁GUI"""
        if self.root:
            self.root.destroy()


# --- For Standalone Testing ---
# You can run this file directly to see the UI.
if __name__ == "__main__":
    # Create a mock object to simulate the vr_arm_node for testing
    class MockVRArm:
        def __init__(self):
            self.vr_device = "pico_webrtc"
            self.eef_type = "G2"
            self.arm_sdk_type = "full"
            self.vr_teleop = self.MockTeleop()

        class MockTeleop:
            def __init__(self):
                self.vr_ctrl_state = {
                    "HBattery": 95.5,
                    "RIsTracked": True,
                    "RBattery": 80.0,
                    "LIsTracked": False,
                    "LBattery": 75.0,
                }
                self.connection_status = {
                    "is_connected": True,
                    "total_connections": 2,
                    "connected_clients": {
                        "client_abc123": {
                            "connect_time": time.time() - 300,
                            "status": "connected",
                        },
                        "client_def456": {
                            "connect_time": time.time() - 60,
                            "status": "connecting",
                        },
                    },
                }

    mock_vr_arm = MockVRArm()
    gui = VRStatusGUI(mock_vr_arm)
    gui.run()
