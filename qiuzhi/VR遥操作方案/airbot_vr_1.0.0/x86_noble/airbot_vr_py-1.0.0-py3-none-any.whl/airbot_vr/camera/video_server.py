import argparse
import asyncio
import json
import logging
import os
import ssl
import uuid
import threading

import cv2
import rclpy
import yaml
from cv_bridge import CvBridge
from rclpy.node import Node
from sensor_msgs.msg import Image as RosImage
from aiohttp import web
from av import VideoFrame
from aiortc import RTCPeerConnection, RTCSessionDescription, VideoStreamTrack
from aiortc.mediastreams import MediaStreamTrack
from aiortc.contrib.media import MediaRelay
from .airbot_camera import RealsenseCamera, USBCamera

ROOT = os.path.dirname(__file__)
logger = logging.getLogger("webrtc-server")
pcs = set()
relay = MediaRelay()


class RosImageSubscriber(Node):
    def __init__(self, topic_name, frame_queue, loop):
        super().__init__("ros_image_subscriber")
        self.subscription = self.create_subscription(
            RosImage,
            # "/usb_cam_node/color/image_bgr8",
            "/camera/camera/color/image_raw",
            lambda msg: self.listener_callback(msg, frame_queue, loop),
            1,
        )
        self.subscription  # prevent unused variable warning
        self.bridge = CvBridge()

    def listener_callback(self, msg, queue, loop):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")
            return
        # Put latest frame into asyncio queue (drop old)
        def put_frame():
            if queue.full():
                _ = queue.get_nowait()
            queue.put_nowait(cv_image)
            self.get_logger().debug("已将新帧推入队列")

        loop.call_soon_threadsafe(put_frame)


class RosVideoStreamTrack(VideoStreamTrack):
    kind = "video"

    def __init__(self, frame_queue):
        super().__init__()
        self.frame_queue = frame_queue
        self.last_log_time = 0  # 初始化上次日志时间戳
        self.log_interval = 5  # 日志打印间隔（秒）

    async def recv(self):
        # Wait for next frame from ROS topic
        printlog = False
        current_time = asyncio.get_event_loop().time()
        if current_time - self.last_log_time >= self.log_interval:
            printlog = True
            logger.info(
                "Track.recv: Waiting for a frame from the queue..."
            )  # <-- 添加日志3
            self.last_log_time = current_time  # 更新上次日志时间
        frame = await self.frame_queue.get()
        if printlog:
            logger.info(f"Track.recv：从队列取到一帧，shape={frame.shape}")

        # Convert BGR to RGB for VideoFrame
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        video_frame = VideoFrame.from_ndarray(rgb, format="rgb24")
        pts, time_base = await self.next_timestamp()
        video_frame.pts = pts
        video_frame.time_base = time_base
        if printlog:
            logger.info(f"RosVideoStreamTrack.recv() returning frame")
        return video_frame


async def index(request):
    content = open(os.path.join(ROOT, "index.html")).read()
    return web.Response(content_type="text/html", text=content)


async def javascript(request):
    content = open(os.path.join(ROOT, "client.js")).read()
    return web.Response(content_type="application/javascript", text=content)


async def offer(request):
    params = await request.json()
    offer = RTCSessionDescription(sdp=params["sdp"], type=params["type"])

    pc = RTCPeerConnection()

    pc_id = f"PeerConnection({uuid.uuid4()})"
    pcs.add(pc)
    logger.info(f"{pc_id} Created for {request.remote}")

    @pc.on("connectionstatechange")
    async def on_state_change():
        logger.info(f"{pc_id} Connection state is {pc.connectionState}")
        if pc.connectionState == "failed":
            await pc.close()
            pcs.discard(pc)

    # Add ROS video track
    ros_track = RosVideoStreamTrack(request.app["frame_queue"])

    # Add track to peer connection
    # Using H.264 requires proper negotiation through SDP, not explicit codec selection in aiortc
    pc.addTrack(relay.subscribe(ros_track))

    # Handle offer/answer exchange first to establish connection
    await pc.setRemoteDescription(offer)

    # Check if H.264 is mentioned in the remote SDP
    has_h264 = "H264" in offer.sdp
    if has_h264:
        logger.info("Remote peer supports H.264, will try to use it in answer")
    else:
        logger.info("Remote peer does not explicitly request H.264")

    # Create answer - H.264 will be used if available on both sides
    answer = await pc.createAnswer()

    # Before setting local description, examine the generated SDP for H.264
    if "H264" in answer.sdp:
        logger.info("Local answer includes H.264 codec")
    else:
        logger.info("Local answer does not include H.264 codec")

    # Set local description
    await pc.setLocalDescription(answer)

    # Note: Offer/answer exchange is handled above

    return web.Response(
        content_type="application/json",
        text=json.dumps(
            {"sdp": pc.localDescription.sdp, "type": pc.localDescription.type}
        ),
    )


async def on_shutdown(app):
    # Close all RTCPeerConnections
    await asyncio.gather(*(pc.close() for pc in pcs))
    pcs.clear()

    # Shutdown ROS if it was used
    if "ros_node" in app and app["ros_node"]:
        rclpy.shutdown()

    # Deinitialize airbot_camera if it was used
    if "airbot_camera" in app and app["airbot_camera"]:
        if hasattr(app["airbot_camera"], "deinit"):
            app["airbot_camera"].deinit()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="WebRTC ROS Image Streamer")
    parser.add_argument("--host", default="0.0.0.0", help="Host IP (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8080, help="Port (default: 8080)")
    parser.add_argument("--topic", default="/camera/image_raw", help="ROS Image topic")
    parser.add_argument(
        "--camera-source",
        default="airbot",
        choices=["ros", "airbot"],
        help="Source of camera frames (default: ros)",
    )
    parser.add_argument("--cert-file", help="SSL certificate file (for HTTPS)")
    parser.add_argument("--key-file", help="SSL key file (for HTTPS)")
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose logging"
    )
    parser.add_argument(
        "--video-bitrate",
        type=int,
        default=1000000,
        help="Video bitrate for H.264 in bps (default: 1Mbps)",
    )
    args = parser.parse_args()

    # Configure logging
    log_level = (
        logging.DEBUG if args.verbose else logging.WARNING
    )  # Modified from logging.INFO to logging.WARNING
    logging.basicConfig(level=log_level)

    loop = asyncio.get_event_loop()
    frame_queue = asyncio.Queue(maxsize=1)

    # Create and run web app
    app = web.Application()
    app["frame_queue"] = frame_queue
    app["args"] = args  # Add this line
    app.on_shutdown.append(on_shutdown)
    app.router.add_get("/", index)
    app.router.add_get("/client.js", javascript)
    app.router.add_post("/offer", offer)

    ros_node = None
    airbot_camera_instance = None

    if args.camera_source == "ros":
        # Initialize ROS
        rclpy.init()
        ros_node = RosImageSubscriber(args.topic, frame_queue, loop)
        # Start ROS spinning in background
        ros_thread = threading.Thread(target=rclpy.spin, args=(ros_node,), daemon=True)
        ros_thread.start()
        app["ros_node"] = ros_node
        logger.info("Using ROS topic as camera source.")
    elif args.camera_source == "airbot":
        # Initialize airbot_camera
        with open("configs/camera.yaml") as file:
            config = yaml.safe_load(file)
        camera_type = config["camera_type"]

        if camera_type == "Realsense":
            airbot_camera_instance = RealsenseCamera()
        elif camera_type == "UsbCam":
            airbot_camera_instance = USBCamera()
        else:
            raise ValueError(
                f"Unsupported camera_type in config for airbot: {camera_type}"
            )

        app["airbot_camera"] = airbot_camera_instance
        logger.info(f"Using {camera_type} from airbot_camera.py as camera source.")

        async def airbot_frame_grabber():
            while True:
                # Assuming get_frame returns a BGR image
                frame = airbot_camera_instance.get_frame(frame_type="bgr")
                if frame is not None:

                    def put_frame():
                        if frame_queue.full():
                            _ = frame_queue.get_nowait()
                        frame_queue.put_nowait(frame)
                        logger.debug("已将新帧推入队列 (Airbot)")

                    loop.call_soon_threadsafe(put_frame)
                await asyncio.sleep(0.033)  # ~30 FPS

        loop.create_task(airbot_frame_grabber())

    # Setup SSL if provided
    ssl_context = None
    if args.cert_file and args.key_file:
        ssl_context = ssl.SSLContext()
        ssl_context.load_cert_chain(args.cert_file, args.key_file)

    web.run_app(app, host=args.host, port=args.port, ssl_context=ssl_context, loop=loop)
