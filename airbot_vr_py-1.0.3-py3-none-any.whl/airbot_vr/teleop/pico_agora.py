import argparse
import time
import threading
import numpy as np
import zmq
import threading
import signal
from scipy.spatial.transform import Rotation
from std_msgs.msg import Float32MultiArray

import vr_agora_py


class PicoAgoraVRTeleop:
    """处理VR设备的姿态数据和手柄输入"""

    def __init__(
        self,
        arm_device="none",
        zmq_pose_port=8000,
        zmq_control_port=8001,
        APP_ID="02502206abca418490d00b0a74e98833",
        USER_ID="ReceiverUser",
        CHANNEL_NAME="agora_test_rtm",
        TOKEN="",
    ):
        print("[PICO AGORA] Initializing Pico Agora VR Teleop...")
        print(
            f"[PICO AGORA] Using APP_ID: {APP_ID}, CHANNEL_NAME: {CHANNEL_NAME}, USER_ID: {USER_ID}, TOKEN: {TOKEN}"
        )

        self.running = True
        self.CHANNEL_NAME = CHANNEL_NAME
        # ZMQ初始化
        self.zmq_context = zmq.Context()

        # 姿态数据发布socket
        self.pose_socket = self.zmq_context.socket(zmq.PUB)
        self.pose_socket.setsockopt(zmq.SNDHWM, 1)
        self.pose_socket.bind(f"tcp://*:{zmq_pose_port}")

        # 控制器数据发布socket
        self.control_socket = self.zmq_context.socket(zmq.PUB)
        self.control_socket.setsockopt(zmq.SNDHWM, 5)
        self.control_socket.bind(f"tcp://*:{zmq_control_port}")

        # vr 手柄输入
        self.vr_ctrl_data = {
            "A": False,
            "B": False,
            "RThU": False,  # 右手柄主触摸板触摸
            "RJ": False,  # 右手柄主触摸板按压
            "RG": False,  # 右手柄抓握键
            "RTr": False,  # 右手柄扳机键
            "X": False,
            "Y": False,
            "LThU": False,  # 左手柄主触摸板触摸
            "LJ": False,  # 左手柄主触摸板按压
            "LG": False,  # 左手柄抓握键
            "LTr": False,  # 左手柄扳机键
            "leftJS": {
                "ud": 0.0,
                "lr": 0.0,
            },  # 左手柄主触摸板推压程度 ud为上下，lr为左右，ud推压至下极限为-1，推压至上极限为1; lr推压至左极限为-1，推压至右极限为1
            "leftTrig": 0.0,  # 左手柄扳机键按压程度
            "leftGrip": 0.0,  # 左手柄抓握键按压程度
            "rightJS": {
                "ud": 0.0,
                "lr": 0.0,
            },  # 右手柄主触摸板 ud为上下，lr为左右，ud推压至下极限为-1，推压至上极限为1; lr推压至左极限为-1，推压至右极限为1
            "rightTrig": 0.0,  # 右手柄扳机键按压程度
            "rightGrip": 0.0,  # 右手柄抓握键按压程度
        }
        self.vr_ctrl_state = {
            "HBattery": 0.0,
            "RIsTracked": False,  # 右控制器追踪
            "RBattery": 0.0,  # 右控制器电量
            "LIsTracked": False,  # 左控制器追踪
            "LBattery": 0.0,  # 左控制器电量
            # 腕带追踪器状态
            "LWristTracked": False,  # 左腕带追踪
            "LWristBattery": 0.0,  # 左腕带电量
            "RWristTracked": False,  # 右腕带追踪
            "RWristBattery": 0.0,  # 右腕带电量
        }

        # 连接状态相关变量
        self.connection_status = {
            "is_connected": False,  # 是否有客户端连接
            "connected_clients": {},  # 已连接的客户端信息 {pc_id: {"connect_time": timestamp, "status": "connected"}}
            "total_connections": 0,  # 总连接数
            "last_connection_time": 0.0,  # 最后连接时间
            "last_disconnection_time": 0.0,  # 最后断开连接时间
        }

        self.arm_device = arm_device

        # vr 姿态数据
        self.head_info = Float32MultiArray()
        self.head_info.data = [0.0] * 7
        self.left_info = Float32MultiArray()
        self.left_info.data = [0.0] * 7
        self.right_info = Float32MultiArray()
        self.right_info.data = [0.0] * 7

        self.vr_agora_server = vr_agora_py.RtmReceiver(APP_ID, USER_ID)

        if not self.vr_agora_server.create_rtm_client():
            print("[PICO AGORA] Failed to create RTM client")
            return

        print("[PICO AGORA] Logging in...")
        self.vr_agora_server.login(TOKEN)

        print(f"[PICO AGORA] Subscribing to channel: {self.CHANNEL_NAME}")
        self.vr_agora_server.subscribe(self.CHANNEL_NAME)

        signal.signal(signal.SIGTERM, self.signal_handler)

        daemon_thread = threading.Thread(target=self.publish_loop, daemon=True)
        daemon_thread.start()

    def signal_handler(self, signum, frame):
        """SIGTERM信号处理函数"""
        print(f"[PICO AGORA] 接收到信号 {signum}，开始优雅关闭...")
        self.running = False

    def receive_loop(self):
        """发布数据循环"""
        while self.running:
            ctrl_data = self.vr_agora_server.get_ctrl_data()
            self.vr_ctrl_data["A"] = ctrl_data.A
            self.vr_ctrl_data["B"] = ctrl_data.B
            self.vr_ctrl_data["RThU"] = ctrl_data.RThU
            self.vr_ctrl_data["RJ"] = ctrl_data.RJ
            self.vr_ctrl_data["RG"] = ctrl_data.RG
            self.vr_ctrl_data["RTr"] = ctrl_data.RTr
            self.vr_ctrl_data["X"] = ctrl_data.X
            self.vr_ctrl_data["Y"] = ctrl_data.Y
            self.vr_ctrl_data["LThU"] = ctrl_data.LThU
            self.vr_ctrl_data["LJ"] = ctrl_data.LJ
            self.vr_ctrl_data["LG"] = ctrl_data.LG
            self.vr_ctrl_data["LTr"] = ctrl_data.LTr
            self.vr_ctrl_data["leftJS"]["ud"] = ctrl_data.leftJS.ud
            self.vr_ctrl_data["leftJS"]["lr"] = ctrl_data.leftJS.lr
            self.vr_ctrl_data["leftTrig"] = ctrl_data.leftTrig
            self.vr_ctrl_data["leftGrip"] = ctrl_data.leftGrip
            self.vr_ctrl_data["rightJS"]["ud"] = ctrl_data.rightJS.ud
            self.vr_ctrl_data["rightJS"]["lr"] = ctrl_data.rightJS.lr
            self.vr_ctrl_data["rightTrig"] = ctrl_data.rightTrig
            self.vr_ctrl_data["rightGrip"] = ctrl_data.rightGrip

            pose_data = self.vr_agora_server.get_pose_data()
            self.left_info.data = [
                pose_data.leftPos.x,
                pose_data.leftPos.y,
                pose_data.leftPos.z,
                pose_data.leftRot.x,
                pose_data.leftRot.y,
                pose_data.leftRot.z,
                pose_data.leftRot.w,
            ]
            self.right_info.data = [
                pose_data.rightPos.x,
                pose_data.rightPos.y,
                pose_data.rightPos.z,
                pose_data.rightRot.x,
                pose_data.rightRot.y,
                pose_data.rightRot.z,
                pose_data.rightRot.w,
            ]
            time.sleep(0.02)

        self.cleanup()

    def publish_loop(self):
        while self.running:
            self._publish_pose_data()
            self._publish_control_data()
            time.sleep(0.02)

    def _publish_pose_data(self):
        try:
            pose_message = {
                "timestamp": time.time(),
                "head_pose": self.head_info.data.tolist()
                if hasattr(self.head_info.data, "tolist")
                else list(self.head_info.data),
                "left_pose": self.left_info.data.tolist()
                if hasattr(self.left_info.data, "tolist")
                else list(self.left_info.data),
                "right_pose": self.right_info.data.tolist()
                if hasattr(self.right_info.data, "tolist")
                else list(self.right_info.data),
                "tracking_state": {
                    "head_battery": float(self.vr_ctrl_state["HBattery"]),
                    "left_tracked": bool(self.vr_ctrl_state["LIsTracked"]),
                    "left_battery": float(self.vr_ctrl_state["LBattery"]),
                    "right_tracked": bool(self.vr_ctrl_state["RIsTracked"]),
                    "right_battery": float(self.vr_ctrl_state["RBattery"]),
                    "left_wrist_tracked": bool(self.vr_ctrl_state["LWristTracked"]),
                    "left_wrist_battery": float(self.vr_ctrl_state["LWristBattery"]),
                    "right_wrist_tracked": bool(self.vr_ctrl_state["RWristTracked"]),
                    "right_wrist_battery": float(self.vr_ctrl_state["RWristBattery"]),
                },
            }

            # 发送姿态数据
            self.pose_socket.send_json(pose_message)

        except Exception as e:
            print(f"Error publishing pose data: {e}")

    def _publish_control_data(self):
        try:
            control_message = {
                "timestamp": time.time(),
                "buttons": {
                    "A": bool(self.vr_ctrl_data["A"]),
                    "B": bool(self.vr_ctrl_data["B"]),
                    "X": bool(self.vr_ctrl_data["X"]),
                    "Y": bool(self.vr_ctrl_data["Y"]),
                    "RThU": bool(self.vr_ctrl_data["RThU"]),
                    "RJ": bool(self.vr_ctrl_data["RJ"]),
                    "RG": bool(self.vr_ctrl_data["RG"]),
                    "RTr": bool(self.vr_ctrl_data["RTr"]),
                    "LThU": bool(self.vr_ctrl_data["LThU"]),
                    "LJ": bool(self.vr_ctrl_data["LJ"]),
                    "LG": bool(self.vr_ctrl_data["LG"]),
                    "LTr": bool(self.vr_ctrl_data["LTr"]),
                },
                "triggers": {
                    "left": float(self.vr_ctrl_data["leftTrig"]),
                    "right": float(self.vr_ctrl_data["rightTrig"]),
                },
                "grips": {
                    "left": float(self.vr_ctrl_data["leftGrip"]),
                    "right": float(self.vr_ctrl_data["rightGrip"]),
                },
                "joysticks": {
                    "left": {
                        "ud": float(self.vr_ctrl_data["leftJS"]["ud"]),
                        "lr": float(self.vr_ctrl_data["leftJS"]["lr"]),
                    },
                    "right": {
                        "ud": float(self.vr_ctrl_data["rightJS"]["ud"]),
                        "lr": float(self.vr_ctrl_data["rightJS"]["lr"]),
                    },
                },
            }

            # 发送控制器数据
            self.control_socket.send_json(control_message)
            # self.log_info("Control data published successfully")

        except Exception as e:
            self.log_error(f"Error publishing control data: {e}")

    def cleanup(self):
        """清理资源"""
        print("执行清理操作...")
        print(f"[PICO AGORA] Unsubscribing from channel: {self.CHANNEL_NAME}")
        self.vr_agora_server.unsubscribe(self.CHANNEL_NAME)
        print("[PICO AGORA] Logging out...")
        self.vr_agora_server.logout()
        print("[PICO AGORA] Destroying RTM client done")


class CoordinateCalibration:
    def calibrate(position, rotation):
        """
        对 position 和 rotation 施加一个绕动坐标系的坐标变换。
        该变换顺序为：先绕新坐标系的y轴旋转90度，再绕最新的z轴旋转180度。
        """
        rot_input = Rotation.from_quat(rotation)
        rot_y = Rotation.from_euler("y", 90, degrees=True)
        rot_z = Rotation.from_euler("z", 180, degrees=True)
        rot_total = rot_y * rot_z

        # 新旋转
        new_rot = rot_input * rot_total
        new_rotation = new_rot.as_quat().tolist()

        # 新位置
        new_position = position

        return new_position, new_rotation


def main():
    """主函数"""
    # 添加命令行参数解析
    parser = argparse.ArgumentParser(description="VR Tracking agora Server")
    parser.add_argument(
        "--pose_port", type=int, default=8000, help="Port (default: 8000)"
    )
    parser.add_argument(
        "--control_port", type=int, default=8001, help="Port (default: 8001)"
    )
    parser.add_argument(
        "--APP_ID",
        type=str,
        default="02502206abca418490d00b0a74e98833",
        help="App ID for Agora",
    )
    parser.add_argument(
        "--CHANNEL_NAME",
        type=str,
        default="agora_test_rtm",
        help="Channel name for Agora",
    )
    parser.add_argument("--TOKEN", type=str, default="", help="Token for Agora")
    parser.add_argument(
        "--USER_ID", type=str, default="ReceiverUser", help="User ID for Agora"
    )
    parser.add_argument("--arm_device", default="none", help="arm_device")
    args = parser.parse_args()

    vr_server = PicoAgoraVRTeleop(
        arm_device=args.arm_device,
        zmq_pose_port=args.pose_port,
        zmq_control_port=args.control_port,
        APP_ID=args.APP_ID,
        USER_ID=args.USER_ID,
        CHANNEL_NAME=args.CHANNEL_NAME,
        TOKEN=args.TOKEN,
    )
    vr_server.receive_loop()


if __name__ == "__main__":
    main()
