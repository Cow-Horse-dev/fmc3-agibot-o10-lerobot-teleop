import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
__package__ = "airbot_vr"

import subprocess
import argparse
import signal
import time
import yaml
import threading

# import rclpy
import zmq
import json
import numpy as np

# from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
from scipy.spatial.transform import Rotation

from .teleop.vr_gui import VRStatusGUI
from .teleop.hand import UdexrealTeleoperator

from .utils import print_green, print_yellow, print_red


class ProcessHandler:
    process = None
    process_go2 = None
    process_d1 = None


class VRArm:
    def __init__(self, config_file):
        print("=== 开始 VRArm.__init__ ===")
        # Node.__init__(self, "vr_node")
        # print("=== Node 初始化完成 ===")

        with open(config_file) as file:
            config = yaml.safe_load(file)

        print("=== 配置文件加载完成 ===")

        self.INIT_JOINTS = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.INIT_GRIPPER = 0.07
        self.INIT_HAND = [0, 0, 0, 0, 0, 0]

        self.robot_type = config["robot"]["robot_type"]
        self.vr_device = config["teleop"]["vr_device"]

        if self.robot_type == "airbot_play":
            self.tctr_gripper = 0.0

            self.arm_init = False
            self.trans_init = None
            self.quat_init = None
            self.arm_init_pose = None

        elif self.robot_type == "airbot_tok2":
            self.tctr_gripper_left = 0.0
            self.tctr_gripper_right = 0.0

            self.arm_init_left = False
            self.arm_init_right = False
            self.trans_init_left = None
            self.trans_init_right = None
            self.quat_init_left = None
            self.quat_init_right = None
            self.arm_init_pose_left = None
            self.arm_init_pose_right = None

        self.worker_script = None
        self.vr_ctrl_state = None
        self.vr_ctrl_data = None
        self.head_info = None
        self.right_info = None
        self.left_info = None

        self.startflag = False
        self.running = True
        self.is_move = False

        self.is_standing = False
        self.JOYSTICK_DEADZONE = 0.3
        self.MOVE_SPEED = 0.5
        self.ROTATE_SPEED = 1.0
        self.HEAD_SPEED = 0.5
        self.head_angle = 0.0

        self.hand_control_threshold = [
            [0, 1000],
            [0, 1000],
            [0, 1000],
            [0, 1000],
            [0, 1000],
            [0, 1000],
        ]

        # 解析配置
        self.is_GUI = config["GUI"]
        self.arm_sdk_type = config["robot"]["arm_sdk_type"]
        self.hand_device = config["teleop"]["hand_device"]
        self.arm_device = config["teleop"]["arm_device"]
        self.handedness = config["teleop"].get("handedness", "left")
        self.glove_freq = config["teleop"]["control_freq"]["udexreal_glove"]
        self.hand_control_freq = config["teleop"]["control_freq"]["eef"]
        self.arm_control_freq = config["teleop"]["control_freq"]["arm"]
        self.pose_port = config["teleop"]["pose_port"]
        self.control_port = config["teleop"]["control_port"]
        self.base_type = config["base"]["device_type"]
        self.base_port = config["base"]["zmq_port"]
        self.base_network_interface = config["base"]["network_interface"]

        if self.robot_type == "airbot_play":
            self.eef_type = config["robot"]["eef_type"]
            self.can_port = config["robot"]["can_port"]
            self.hand_id = config["robot"]["hand_id"]
        elif self.robot_type == "airbot_tok2":
            self.eef_type_left = config["robot"]["eef_type_left"]
            self.eef_type_right = config["robot"]["eef_type_right"]
            self.can_port_left = config["robot"]["can_port_left"]
            self.can_port_right = config["robot"]["can_port_right"]
            self.hand_id_left = config["robot"]["hand_id_left"]
            self.hand_id_right = config["robot"]["hand_id_right"]

        if self.vr_device == "pico_agora":
            self.agora_APP_ID = config["teleop"]["agora"]["APP_ID"]
            self.agora_CHANNEL_NAME = config["teleop"]["agora"]["CHANNEL_NAME"]
            self.agora_TOKEN = config["teleop"]["agora"]["TOKEN"]
            self.agora_USER_ID = config["teleop"]["agora"]["USER_ID"]

        # 配置验证
        self._validate_config()
        print_green("配置文件解析完成")

        self.init_dataset(self.vr_device)

        # 初始化VR设备
        if (
            self.vr_device == "pico_webrtc"
            or self.vr_device == "quest_webrtc"
            or self.vr_device == "pico_agora"
        ):
            self.zmq_context = zmq.Context()
            # 订阅姿态数据
            self.pose_socket = self.zmq_context.socket(zmq.SUB)
            self.pose_socket.setsockopt(zmq.CONFLATE, 1)
            self.pose_socket.connect(f"tcp://localhost:{self.pose_port}")
            self.pose_socket.setsockopt_string(zmq.SUBSCRIBE, "")

            # 订阅控制器数据
            self.control_socket = self.zmq_context.socket(zmq.SUB)
            self.control_socket.setsockopt(zmq.CONFLATE, 1)
            self.control_socket.connect(f"tcp://localhost:{self.control_port}")
            self.control_socket.setsockopt_string(zmq.SUBSCRIBE, "")

            if self.base_type == "go2":
                self.zmq_context_go2 = zmq.Context()
                self.go2_socket = self.zmq_context_go2.socket(zmq.REQ)
                self.go2_socket.RCVTIMEO = 2000
                self.go2_socket.connect(f"tcp://localhost:{self.base_port}")

            if self.base_type == "d1":
                self.zmq_context_d1 = zmq.Context()
                self.d1_socket = self.zmq_context_d1.socket(zmq.PUB)
                # self.d1_socket.RCVTIMEO = 2000
                self.d1_socket.connect(f"tcp://localhost:{self.base_port}")

            # self.worker_script = "airbot_vr/teleop/pico_webrtc.py"
            # self.worker_script_go2 = "airbot_vr/robot/unitree/go2_zmq.py"
            if self.vr_device == "pico_webrtc":
                try:
                    from airbot_vr.teleop import pico_webrtc

                    self.worker_script = pico_webrtc.__file__
                    print(f"找到 pico_webrtc: {self.worker_script}")

                    if self.base_type == "go2":
                        from airbot_vr.robot.unitree import go2_zmq

                        self.worker_script_go2 = go2_zmq.__file__
                        print(f"找到 go2_zmq: {self.worker_script_go2}")

                    elif self.base_type == "d1":
                        from airbot_vr.robot.ddt import d1_zmq

                        self.worker_script_d1 = d1_zmq.__file__
                        print(f"找到 d1_zmq: {self.worker_script_d1}")

                except ImportError as e:
                    print(f"导入失败: {e}")
                    import airbot_vr

                    package_path = os.path.dirname(airbot_vr.__file__)
                    self.worker_script = os.path.join(
                        package_path, "teleop", "pico_webrtc.py"
                    )
                    if self.base_type == "go2":
                        self.worker_script_go2 = os.path.join(
                            package_path, "robot", "unitree", "go2_zmq.py"
                        )
                    elif self.base_type == "d1":
                        self.worker_script_d1 = os.path.join(
                            package_path, "robot", "ddt", "d1_zmq.py"
                        )
            elif self.vr_device == "quest_webrtc":
                try:
                    from airbot_vr.teleop import quest_webrtc

                    self.worker_script = quest_webrtc.__file__
                    print(f"找到 quest_webrtc: {self.worker_script}")

                    if self.base_type == "go2":
                        from airbot_vr.robot.unitree import go2_zmq

                        self.worker_script_go2 = go2_zmq.__file__
                        print(f"找到 go2_zmq: {self.worker_script_go2}")

                    elif self.base_type == "d1":
                        from airbot_vr.robot.ddt import d1_zmq

                        self.worker_script_d1 = d1_zmq.__file__
                        print(f"找到 d1_zmq: {self.worker_script_d1}")

                except ImportError as e:
                    print(f"导入失败: {e}")
                    import airbot_vr

                    package_path = os.path.dirname(airbot_vr.__file__)
                    self.worker_script = os.path.join(
                        package_path, "teleop", "quest_webrtc.py"
                    )
                    if self.base_type == "go2":
                        self.worker_script_go2 = os.path.join(
                            package_path, "robot", "unitree", "go2_zmq.py"
                        )

                    elif self.base_type == "d1":
                        self.worker_script_d1 = os.path.join(
                            package_path, "robot", "ddt", "d1_zmq.py"
                        )
            elif self.vr_device == "pico_agora":
                try:
                    from airbot_vr.teleop import pico_agora

                    self.worker_script = pico_agora.__file__
                    print(f"找到 pico_agora: {self.worker_script}")

                    if self.base_type == "go2":
                        from airbot_vr.robot.unitree import go2_zmq

                        self.worker_script_go2 = go2_zmq.__file__
                        print(f"找到 go2_zmq: {self.worker_script_go2}")

                    elif self.base_type == "d1":
                        from airbot_vr.robot.ddt import d1_zmq

                        self.worker_script_d1 = d1_zmq.__file__
                        print(f"找到 d1_zmq: {self.worker_script_d1}")

                except ImportError as e:
                    print(f"导入失败: {e}")
                    import airbot_vr

                    package_path = os.path.dirname(airbot_vr.__file__)
                    self.worker_script = os.path.join(
                        package_path, "teleop", "pico_agora.py"
                    )
                    if self.base_type == "go2":
                        self.worker_script_go2 = os.path.join(
                            package_path, "robot", "unitree", "go2_zmq.py"
                        )

                    elif self.base_type == "d1":
                        self.worker_script_d1 = os.path.join(
                            package_path, "robot", "ddt", "d1_zmq.py"
                        )
            if self.vr_device == "pico_webrtc" or self.vr_device == "quest_webrtc":
                self.start_WebRTC()
            elif self.vr_device == "pico_agora":
                self.start_AGORA()

            if self.base_type == "go2":
                self.start_GO2()
            elif self.base_type == "d1":
                self.start_D1()
            thread_process = threading.Thread(target=self.wait)
            thread_process.daemon = True  # 设置为守护线程，主程序结束时会自动停止
            thread_process.start()

        else:
            raise ValueError(
                f"Invalid vr_device, must be one of quest_webrtc, pico_webrtc"
            )

        self.process = None
        self.process_go2 = None
        self.process_d1 = None
        # signal.signal(signal.SIGINT, self.stop_WebRTC)

        # 初始化机械臂控制器
        if self.arm_sdk_type == "thin":
            from .robot.servo_thin import Arm
        elif self.arm_sdk_type == "full":
            from .robot.servo import Arm
        else:
            raise RuntimeError(f"wrong arm_sdk_type {self.arm_sdk_type}")

        if self.robot_type == "airbot_play":
            self.arm = Arm(self.eef_type, self.hand_id, self.can_port)
            self.arm.init()
            self.reset_pose()
        elif self.robot_type == "airbot_tok2":
            self.arm_left = Arm(
                self.eef_type_left, self.hand_id_left, self.can_port_left
            )
            self.arm_right = Arm(
                self.eef_type_right, self.hand_id_right, self.can_port_right
            )
            self.arm_left.init()
            self.arm_right.init()
            self.reset_pose()

        # 初始化手控制器
        self.is_hand_joint_ctrl_mode = True  # 默认控制模式为手关节控制模式
        self.hand_ctrl_data = [0, 0, 0, 0, 0, 0]
        self.pre_y_state = False

        # 根据eef_type决定是否初始化手部遥操作器
        if self.robot_type == "airbot_play":
            if self.eef_type not in ["none", "G2"]:
                self._init_hand_teleoperator()
                print_yellow("手部初始化完成")
            else:
                print_yellow(f"eef_type为{self.eef_type}，跳过手部遥操作器初始化")

        # 初始化发布频率
        self.pub_freq = self.arm_control_freq
        time.sleep(1)

        # self.timer = self.create_timer(1.0 / self.pub_freq, self.teleopProcess)
        thread = threading.Thread(target=self.teleopProcess)
        thread.daemon = True  # 设置为守护线程，主程序结束时会自动停止
        thread.start()

        # 初始化GUI界面
        if self.is_GUI == "True":
            self.gui = None
            self.gui_thread = None
            self.start_gui()

    def _validate_config(self):
        """验证配置的合理性"""

        # 检查robot_type
        if self.robot_type not in ["airbot_play", "airbot_tok2"]:
            print_red(f"无效的robot_type: {self.robot_type}")
            sys.exit(1)

        # 检查eef_type
        if self.robot_type == "airbot_play":
            if not self.eef_type or self.eef_type not in [
                "G2",
                "INS_RH56DFX",
                "INS_RH56BFX",
                "INS_RH56E2",
                "INS_RH56F1",
                "BRAINCO_REVO1",
                "BRAINCO_REVO2",
                "ROH_LITES001",
                "ROH_A002",
                "LINKERBOT_O6",
                "none",
            ]:
                print_red(f"无效的eef_type: {self.eef_type}")
                sys.exit(1)
        elif self.robot_type == "airbot_tok2":
            if not self.eef_type_left or self.eef_type_left not in [
                "G2",
                "none",
            ]:
                print_red(f"无效的eef_type_left: {self.eef_type_left}")
                sys.exit(1)
            if not self.eef_type_right or self.eef_type_right not in [
                "G2",
                "none",
            ]:
                print_red(f"无效的eef_type_right: {self.eef_type_right}")
                sys.exit(1)

        # 检查arm_sdk_type
        if self.arm_sdk_type not in ["full", "thin"]:
            print_red(f"无效的arm_sdk_type: {self.arm_sdk_type}")
            sys.exit(1)
        else:
            if self.arm_sdk_type == "full":
                print_red(f"暂不支持的arm_sdk_type: {self.arm_sdk_type}")
                sys.exit(1)

        # 检查vr_device
        if self.vr_device not in ["quest_webrtc", "pico_webrtc", "pico_agora"]:
            print_red(f"无效的vr_device: {self.vr_device}")
            sys.exit(1)

        # 检查arm_device
        if self.arm_device not in ["pico_wrist", "pico", "quest"]:
            print_red(f"无效的arm_device: {self.arm_device}")
            sys.exit(1)

        # 检查hand_device
        if self.hand_device not in ["udexreal", "pico", "quest"]:
            print_red(f"无效的hand_device: {self.hand_device}")
            sys.exit(1)

        # 检查handedness
        if self.handedness not in ["left", "right"]:
            print_red(f"无效的handedness: {self.handedness}")
            sys.exit(1)

        # 检查控制频率
        if self.glove_freq <= 0:
            print_red(f"无效的udexreal_glove频率: {self.glove_freq}")
            sys.exit(1)
        if self.hand_control_freq <= 0:
            print_red(f"无效的eef控制频率: {self.hand_control_freq}")
            sys.exit(1)
        if self.arm_control_freq <= 0:
            print_red(f"无效的arm位置更新频率: {self.arm_control_freq}")
            sys.exit(1)

        # 检查base
        if self.base_type not in ["none", "go2", "d1"]:
            print_red(f"无效的device_type: {self.base_type}")
            sys.exit(1)

        # 检查GUI
        if self.is_GUI not in [False, True]:
            print_red(f"无效的GUI: {self.is_GUI}")
            sys.exit(1)

        # 检查设备组合约束
        if self.vr_device == "quest_webrtc":
            if self.arm_device != "quest":
                print_red(
                    f"无效的VR设备组合: 使用Quest时, 正确组合应该为 vr_device: quest_webrtc, arm_device: quest, hand_device: quest"
                )
                sys.exit(1)
            if self.hand_device != "quest":
                print_red(
                    f"无效的VR设备组合: 使用Quest时, 正确组合应该为 vr_device: quest_webrtc, arm_device: quest, hand_device: quest"
                )
                sys.exit(1)

        if self.vr_device == "pico_webrtc":
            if self.arm_device not in ["pico_wrist", "pico"]:
                print_red(f"无效的VR设备组合: 使用Quest时, arm_device应为pico_wrist或者pico")
                sys.exit(1)
            if self.hand_device not in ["udexreal", "pico"]:
                print_red(f"无效的VR设备组合: 使用Quest时, hand_device应为udexreal或者pico")
                sys.exit(1)

            if self.arm_device == "pico_wrist":
                if self.hand_device != "udexreal":
                    print_yellow("警告: 在使用腕带的时候推荐使用手套, 否则可能导致控制冲突")

            if self.arm_device == "pico":
                if self.hand_device == "udexreal":
                    print_yellow("警告: 在使用手柄的时候不推荐使用手套")

    def _init_hand_teleoperator(self):
        """初始化手部遥操作器"""
        if self.hand_device == "udexreal":
            self.hand_teleoperator = UdexrealTeleoperator(
                handedness=self.handedness, control_freq=self.glove_freq
            )
        elif self.hand_device == "pico":
            # self.hand_teleoperator = PicoHandTeleoperator(self.teleop)
            pass
        else:
            self.hand_teleoperator = None
            print_yellow(f"未知的手部遥操作设备: {self.hand_device}")

        if self.hand_device == "udexreal":
            if self.hand_teleoperator and self.hand_teleoperator.init():
                self.hand_teleoperator.start_listening()
                print_green(f"手部遥操作设备 {self.hand_device} 初始化成功")
            else:
                print_red(f"手部遥操作设备 {self.hand_device} 初始化失败")
                raise RuntimeError("手部遥操作设备初始化失败")

    def init_dataset(self, device_type):
        if (
            device_type == "pico_webrtc"
            or device_type == "quest_webrtc"
            or device_type == "pico_agora"
        ):
            # 初始化数据结构 - 与源代码格式完全一致
            self.vr_ctrl_state = {
                "HBattery": 0.0,
                "RIsTracked": False,
                "RBattery": 0.0,
                "LIsTracked": False,
                "LBattery": 0.0,
                "LWristTracked": False,
                "LWristBattery": 0.0,
                "RWristTracked": False,
                "RWristBattery": 0.0,
            }

            self.vr_ctrl_data = {
                "A": False,
                "B": False,
                "RThU": False,
                "RJ": False,
                "RG": False,
                "RTr": False,
                "X": False,
                "Y": False,
                "LThU": False,
                "LJ": False,
                "LG": False,
                "LTr": False,
                "leftJS": {"ud": 0.0, "lr": 0.0},
                "leftTrig": 0.0,
                "leftGrip": 0.0,
                "rightJS": {"ud": 0.0, "lr": 0.0},
                "rightTrig": 0.0,
                "rightGrip": 0.0,
            }

            self.head_info = Float32MultiArray()
            self.head_info.data = [0.0] * 7
            self.left_info = Float32MultiArray()
            self.left_info.data = [0.0] * 7
            self.right_info = Float32MultiArray()
            self.right_info.data = [0.0] * 7

        print("Ros2VRCtl node is up")

    def reset_pose(self):
        print_yellow("Robot reset to zero position")
        if self.robot_type == "airbot_play":
            self.arm.update_joints(self.INIT_JOINTS)

            # 重置初始化标志
            self.arm_init = False
            self.trans_init = None
            self.quat_init = None
            self.arm_init_pose = None

        elif self.robot_type == "airbot_tok2":
            self.arm_left.update_joints(self.INIT_JOINTS)
            self.arm_right.update_joints(self.INIT_JOINTS)
            # 重置初始化标志
            self.arm_init_left = False
            self.arm_init_right = False
            self.trans_init_left = None
            self.trans_init_right = None
            self.quat_init_left = None
            self.quat_init_right = None
            self.arm_init_pose_left = None
            self.arm_init_pose_right = None

        if self.base_type == "go2":
            if ProcessHandler.process_go2 is not None:
                self.send_go2_command("stop_move")
        elif self.base_type == "d1":
            if ProcessHandler.process_d1 is not None:
                self.send_d1_command("stop_move")

    def start_gui(self):
        """启动GUI界面 - 仅在pico_webrtc设备时启动"""
        if self.vr_device == "pico_webrtc":

            def run_gui():
                self.gui = VRStatusGUI(self)
                self.gui.run()

            self.gui_thread = threading.Thread(target=run_gui, daemon=True)
            self.gui_thread.start()
            print_green("VR状态监控界面已启动")
        else:
            print_yellow(f"设备类型为{self.vr_device}，跳过GUI启动")

    def start_WebRTC(self):
        """启动WebRTC服务器进程"""
        try:
            print(f"=== 开始启动 WebRTC 进程 ===")
            print(f"worker_script: {self.worker_script}")
            # print(f"eef_type: {self.eef_type}")

            # 检查文件是否存在
            if not os.path.exists(self.worker_script):
                print_red(f"错误: 文件不存在: {self.worker_script}")
                self.process = None
                return False

            # 构建命令行参数
            args = [
                sys.executable,
                self.worker_script,
                "--arm_device",
                self.arm_device,
                "--pose_port",
                str(self.pose_port),
                "--control_port",
                str(self.control_port),
            ]

            print_green(f"启动WebRTC进程命令: {' '.join(args)}")

            # 确保正确设置 self.process
            self.process = subprocess.Popen(args)
            print_green(f"WebRTC进程已启动 PID: {self.process.pid}")
            print_green(f"self.process 对象: {self.process}")

            # 等待进程启动
            time.sleep(2)

            # 检查进程是否还在运行
            returncode = self.process.poll()
            print_green(f"进程返回码: {returncode}")

            if returncode is not None:
                print_red("警告: WebRTC进程启动后立即退出")
                return False

            print_green("WebRTC进程启动成功")
            ProcessHandler.process = self.process
            return True

        except Exception as e:
            print_red(f"启动WebRTC进程失败: {e}")
            print(f"异常类型: {type(e).__name__}")
            import traceback

            traceback.print_exc()
            self.process = None  # 确保设置为 None
            return False

    def start_AGORA(self):
        """启动AGORA服务器进程"""
        try:
            print(f"=== 开始启动 AGORA 进程 ===")
            print(f"worker_script: {self.worker_script}")
            # print(f"eef_type: {self.eef_type}")

            # 检查文件是否存在
            if not os.path.exists(self.worker_script):
                print_red(f"错误: 文件不存在: {self.worker_script}")
                self.process = None
                return False

            # 构建命令行参数
            args = [
                sys.executable,
                self.worker_script,
                "--arm_device",
                self.arm_device,
                "--pose_port",
                str(self.pose_port),
                "--control_port",
                str(self.control_port),
                "--APP_ID",
                self.agora_APP_ID,
                "--CHANNEL_NAME",
                self.agora_CHANNEL_NAME,
                "--TOKEN",
                self.agora_TOKEN,
                "--USER_ID",
                self.agora_USER_ID,
            ]

            print_green(f"启动AGORA进程命令: {' '.join(args)}")

            # 确保正确设置 self.process
            self.process = subprocess.Popen(args)
            print_green(f"AGORA进程已启动 PID: {self.process.pid}")
            print_green(f"self.process 对象: {self.process}")

            # 等待进程启动
            time.sleep(2)

            # 检查进程是否还在运行
            returncode = self.process.poll()
            print_green(f"进程返回码: {returncode}")

            if returncode is not None:
                print_red("警告: AGORA进程启动后立即退出")
                return False

            print_green("AGORA进程启动成功")
            ProcessHandler.process = self.process
            return True

        except Exception as e:
            print_red(f"启动AGORA进程失败: {e}")
            print(f"异常类型: {type(e).__name__}")
            import traceback

            traceback.print_exc()
            self.process = None  # 确保设置为 None
            return False

    def start_GO2(self):
        """启动GO2服务器进程"""
        try:
            print(f"=== 开始启动 GO2 进程 ===")
            print(f"worker_script: {self.worker_script_go2}")
            print(f"network_interface: {self.base_network_interface}")
            print(f"zmq_port: {self.base_port}")

            # 检查文件是否存在
            if not os.path.exists(self.worker_script_go2):
                print_red(f"错误: 文件不存在: {self.worker_script_go2}")
                self.process_go2 = None
                return False

            # 构建命令行参数
            args = [
                sys.executable,
                self.worker_script_go2,
                self.base_network_interface,
                str(self.base_port),
            ]

            print_green(f"启动GO2进程命令: {' '.join(args)}")

            # 确保正确设置 self.process
            self.process_go2 = subprocess.Popen(args)
            print_green(f"GO2进程已启动 PID: {self.process_go2.pid}")
            print_green(f"self.process 对象: {self.process_go2}")

            # 等待进程启动
            time.sleep(2)

            # 检查进程是否还在运行
            returncode = self.process_go2.poll()
            print_green(f"进程返回码: {returncode}")

            if returncode is not None:
                print_red("警告: GO2进程启动后立即退出")
                return False

            print_green("GO2进程启动成功")
            ProcessHandler.process_go2 = self.process_go2
            return True

        except Exception as e:
            print_red(f"启动GO2进程失败: {e}")
            print_red(f"异常类型: {type(e).__name__}")
            import traceback

            traceback.print_exc()
            self.process_go2 = None  # 确保设置为 None
            return False

    def start_D1(self):
        """启动D1服务器进程"""
        try:
            print(f"=== 开始启动 D1 进程 ===")
            print(f"worker_script: {self.worker_script_d1}")
            print(f"zmq_port: {self.base_port}")

            # 检查文件是否存在
            if not os.path.exists(self.worker_script_d1):
                print_red(f"错误: 文件不存在: {self.worker_script_d1}")
                self.process_d1 = None
                return False

            # 构建命令行参数
            args = [
                sys.executable,
                self.worker_script_d1,
                str(self.base_port),
            ]

            print_green(f"启动D1进程命令: {' '.join(args)}")

            # 确保正确设置 self.process
            self.process_d1 = subprocess.Popen(args)
            print_green(f"D1进程已启动 PID: {self.process_d1.pid}")
            print_green(f"self.process 对象: {self.process_d1}")

            # 等待进程启动
            time.sleep(2)

            # 检查进程是否还在运行
            returncode = self.process_d1.poll()
            print_green(f"进程返回码: {returncode}")

            if returncode is not None:
                print_red("警告: D1进程启动后立即退出")
                return False

            print_green("D1进程启动成功")
            ProcessHandler.process_d1 = self.process_d1
            return True

        except Exception as e:
            print_red(f"启动D1进程失败: {e}")
            print_red(f"异常类型: {type(e).__name__}")
            import traceback

            traceback.print_exc()
            self.process_d1 = None  # 确保设置为 None
            return False

    def stop_WebRTC(self, signum=None, frame=None):
        print(f"=== 收到信号 {signum}，调用 stop_WebRTC ===")
        print(f"self 对象ID: {id(self)}")
        print(f"当前 self.process: {self.process}")
        print(f"self.process 类型: {type(self.process)}")
        print(f"hasattr(self, 'process'): {hasattr(self, 'process')}")

        # 检查所有属性
        print("所有包含 'process' 的属性:")
        for attr_name in dir(self):
            if "process" in attr_name.lower():
                attr_value = getattr(self, attr_name)
                print(f"  {attr_name}: {attr_value} (类型: {type(attr_value)})")

        self.running = False

        if self.process is not None:
            print(f"进程 PID: {self.process.pid}")
            returncode = self.process.poll()
            print(f"进程返回码: {returncode}")

            if returncode is None:
                print("进程仍在运行，正在终止...")
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                    print("WebRTC进程已停止")
                except subprocess.TimeoutExpired:
                    print("进程未响应，强制杀死...")
                    self.process.kill()
                    self.process.wait()
                    print("WebRTC进程已被强制杀死")
            else:
                print(f"进程已退出，返回码: {returncode}")
        else:
            print("self.process 为 None")
            # 检查是否在其他地方被修改
            print("检查可能的问题...")

    def stop_AGORA(self, signum=None, frame=None):
        print(f"=== 收到信号 {signum}，调用 stop_AGORA ===")
        print(f"self 对象ID: {id(self)}")
        print(f"当前 self.process: {self.process}")
        print(f"self.process 类型: {type(self.process)}")
        print(f"hasattr(self, 'process'): {hasattr(self, 'process')}")

        # 检查所有属性
        print("所有包含 'process' 的属性:")
        for attr_name in dir(self):
            if "process" in attr_name.lower():
                attr_value = getattr(self, attr_name)
                print(f"  {attr_name}: {attr_value} (类型: {type(attr_value)})")

        self.running = False

        if self.process is not None:
            print(f"进程 PID: {self.process.pid}")
            returncode = self.process.poll()
            print(f"进程返回码: {returncode}")

            if returncode is None:
                print("进程仍在运行，正在终止...")
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                    print("AGORA进程已停止")
                except subprocess.TimeoutExpired:
                    print("进程未响应，强制杀死...")
                    self.process.kill()
                    self.process.wait()
                    print("AGORA进程已被强制杀死")
            else:
                print(f"进程已退出，返回码: {returncode}")
        else:
            print("self.process 为 None")
            # 检查是否在其他地方被修改
            print("检查可能的问题...")

    def stop_GO2(self, signum=None, frame=None):
        print(f"=== 收到信号 {signum}，调用 stop_GO2 ===")
        print(f"self 对象ID: {id(self)}")
        print(f"当前 self.process: {self.process_go2}")
        print(f"self.process 类型: {type(self.process_go2)}")
        print(f"hasattr(self, 'process'): {hasattr(self, 'process')}")

        # 检查所有属性
        print("所有包含 'process' 的属性:")
        for attr_name in dir(self):
            if "process" in attr_name.lower():
                attr_value = getattr(self, attr_name)
                print(f"  {attr_name}: {attr_value} (类型: {type(attr_value)})")

        self.running = False

        if self.process_go2 is not None:
            print(f"进程 PID: {self.process_go2.pid}")
            returncode = self.process_go2.poll()
            print(f"进程返回码: {returncode}")

            if returncode is None:
                print("进程仍在运行，正在终止...")
                self.process_go2.terminate()
                try:
                    self.process_go2.wait(timeout=5)
                    print("GO2进程已停止")
                except subprocess.TimeoutExpired:
                    print("进程未响应，强制杀死...")
                    self.process_go2.kill()
                    self.process_go2.wait()
                    print("GO2进程已被强制杀死")
            else:
                print(f"进程已退出，返回码: {returncode}")
        else:
            print("self.process_go2 为 None")
            # 检查是否在其他地方被修改
            print("检查可能的问题...")

    def stop_D1(self, signum=None, frame=None):
        print(f"=== 收到信号 {signum}，调用 stop_D1 ===")
        print(f"self 对象ID: {id(self)}")
        print(f"当前 self.process: {self.process_d1}")
        print(f"self.process 类型: {type(self.process_d1)}")
        print(f"hasattr(self, 'process'): {hasattr(self, 'process')}")

        # 检查所有属性
        print("所有包含 'process' 的属性:")
        for attr_name in dir(self):
            if "process" in attr_name.lower():
                attr_value = getattr(self, attr_name)
                print(f"  {attr_name}: {attr_value} (类型: {type(attr_value)})")

        self.running = False

        if self.process_d1 is not None:
            print(f"进程 PID: {self.process_d1.pid}")
            returncode = self.process_d1.poll()
            print(f"进程返回码: {returncode}")

            if returncode is None:
                print("进程仍在运行，正在终止...")
                self.process_d1.terminate()
                try:
                    self.process_d1.wait(timeout=1)
                    print("D1进程已停止")
                except subprocess.TimeoutExpired:
                    print("进程未响应，强制杀死...")
                    self.process_d1.kill()
                    self.process_d1.wait()
                    print("D1进程已被强制杀死")
            else:
                print(f"进程已退出，返回码: {returncode}")
        else:
            print("self.process_d1 为 None")
            # 检查是否在其他地方被修改
            print("检查可能的问题...")

    def wait(self):
        try:
            while self.running:
                self.receive_zmq_data()
                # print(self.right_info.data)
                time.sleep(0.01)
        except KeyboardInterrupt:
            """关闭ZMQ连接"""
            print_yellow("开始关闭进程")
            self.pose_socket.close()
            self.control_socket.close()
            self.zmq_context.term()
            if self.vr_device == "pico_webrtc" or self.vr_device == "quest_webrtc":
                self.stop_WebRTC()
            elif self.vr_device == "pico_agora":
                self.stop_AGORA()
            if self.base_type == "go2":
                self.go2_socket.close()
                self.zmq_context_go2.term()
                self.stop_GO2()
            elif self.base_type == "d1":
                self.d1_socket.close()
                self.zmq_context_d1.term()
                self.stop_D1()

    def receive_zmq_data(self):
        """接收并处理ZMQ数据"""
        # 非阻塞接收姿态数据
        try:
            pose_msg = self.pose_socket.recv_json(zmq.NOBLOCK)
            self._update_pose_data(pose_msg)
        except zmq.Again:
            pass

        # 非阻塞接收控制器数据
        try:
            control_msg = self.control_socket.recv_json(zmq.NOBLOCK)
            self._update_control_data(control_msg)
        except zmq.Again:
            pass

    def _update_pose_data(self, pose_msg):
        """更新姿态数据"""
        try:
            # 更新头部姿态
            if "head_pose" in pose_msg:
                head_data = pose_msg["head_pose"]
                if len(head_data) == 7:
                    self.head_info.data = head_data

            # 更新左手姿态
            if "left_pose" in pose_msg:
                left_data = pose_msg["left_pose"]
                if len(left_data) == 7:
                    self.left_info.data = left_data

            # 更新右手姿态
            if "right_pose" in pose_msg:
                right_data = pose_msg["right_pose"]
                if len(right_data) == 7:
                    self.right_info.data = right_data

            # 更新追踪状态
            if "tracking_state" in pose_msg:
                state = pose_msg["tracking_state"]
                self.vr_ctrl_state.update(
                    {
                        "HBattery": float(state.get("head_battery", 0.0)),
                        "LIsTracked": bool(state.get("left_tracked", False)),
                        "LBattery": float(state.get("left_battery", 0.0)),
                        "RIsTracked": bool(state.get("right_tracked", False)),
                        "RBattery": float(state.get("right_battery", 0.0)),
                        "LWristTracked": bool(state.get("left_wrist_tracked", False)),
                        "LWristBattery": float(state.get("left_wrist_battery", 0.0)),
                        "RWristTracked": bool(state.get("right_wrist_tracked", False)),
                        "RWristBattery": float(state.get("right_wrist_battery", 0.0)),
                    }
                )
        except Exception as e:
            print(f"Error updating pose data: {e}")

    def _update_control_data(self, control_msg):
        """更新控制器数据到原始格式"""
        if "buttons" in control_msg:
            buttons = control_msg["buttons"]
            self.vr_ctrl_data["A"] = buttons.get("A", False)
            self.vr_ctrl_data["B"] = buttons.get("B", False)
            self.vr_ctrl_data["X"] = buttons.get("X", False)
            self.vr_ctrl_data["Y"] = buttons.get("Y", False)
            self.vr_ctrl_data["RThU"] = buttons.get("RThU", False)
            self.vr_ctrl_data["RJ"] = buttons.get("RJ", False)
            self.vr_ctrl_data["RG"] = buttons.get("RG", False)
            self.vr_ctrl_data["RTr"] = buttons.get("RTr", False)
            self.vr_ctrl_data["LThU"] = buttons.get("LThU", False)
            self.vr_ctrl_data["LJ"] = buttons.get("LJ", False)
            self.vr_ctrl_data["LG"] = buttons.get("LG", False)
            self.vr_ctrl_data["LTr"] = buttons.get("LTr", False)

        if "triggers" in control_msg:
            triggers = control_msg["triggers"]
            self.vr_ctrl_data["leftTrig"] = triggers.get("left", 0.0)
            self.vr_ctrl_data["rightTrig"] = triggers.get("right", 0.0)

        if "grips" in control_msg:
            grips = control_msg["grips"]
            self.vr_ctrl_data["leftGrip"] = grips.get("left", 0.0)
            self.vr_ctrl_data["rightGrip"] = grips.get("right", 0.0)

        if "joysticks" in control_msg:
            joysticks = control_msg["joysticks"]
            if "left" in joysticks:
                self.vr_ctrl_data["leftJS"]["ud"] = joysticks["left"].get("ud", 0.0)
                self.vr_ctrl_data["leftJS"]["lr"] = joysticks["left"].get("lr", 0.0)
            if "right" in joysticks:
                self.vr_ctrl_data["rightJS"]["ud"] = joysticks["right"].get("ud", 0.0)
                self.vr_ctrl_data["rightJS"]["lr"] = joysticks["right"].get("lr", 0.0)

    def teleopProcess(self):
        while self.running:

            if self.robot_type == "airbot_play":
                if self.hand_device == "udexreal":
                    if self.handedness == "left":
                        enable_button = self.vr_ctrl_data["A"]
                        reset_button = self.vr_ctrl_data["B"]
                        start_trigger = self.vr_ctrl_data["RTr"]
                    elif self.handedness == "right":
                        enable_button = self.vr_ctrl_data["X"]
                        reset_button = self.vr_ctrl_data["Y"]
                        start_trigger = self.vr_ctrl_data["LTr"]
                elif self.hand_device == "pico" or self.hand_device == "quest":
                    if self.handedness == "left":
                        enable_button = self.vr_ctrl_data["A"]
                        reset_button = self.vr_ctrl_data["B"]
                        start_trigger = self.vr_ctrl_data["RTr"]
                    elif self.handedness == "right":
                        enable_button = self.vr_ctrl_data["X"]
                        reset_button = self.vr_ctrl_data["Y"]
                        start_trigger = self.vr_ctrl_data["LTr"]
            elif self.robot_type == "airbot_tok2":
                if self.hand_device == "pico" or self.hand_device == "quest":
                    enable_button = self.vr_ctrl_data["A"]
                    reset_button = self.vr_ctrl_data["B"]
                    start_trigger_left = self.vr_ctrl_data["LTr"]
                    start_trigger_right = self.vr_ctrl_data["RTr"]

            if self.robot_type == "airbot_play":
                if self.eef_type == "G2":
                    if self.handedness == "left":
                        gripper = self.vr_ctrl_data["leftGrip"]
                    elif self.handedness == "right":
                        gripper = self.vr_ctrl_data["rightGrip"]
            elif self.robot_type == "airbot_tok2":
                if self.eef_type_left == "G2" and self.eef_type_right == "G2":
                    gripper_left = self.vr_ctrl_data["leftGrip"]
                    gripper_right = self.vr_ctrl_data["rightGrip"]

            if enable_button:
                if self.startflag == False:
                    self.startflag = True
                    print_yellow("start VR control")

            if reset_button:
                if self.startflag == True:
                    self.startflag = False
                    self.reset_pose()
                    print_yellow("RESET Arm position")
                    self.arm_init = False
                    self.trans_init = None
                    self.quat_init = None
                    self.arm_init_pose = None
                    print_yellow("stop Arm control")

            if self.robot_type == "airbot_play":
                # 机械臂控制逻辑 - 根据arm_device选择控制方式
                if self.arm_device == "pico" or self.arm_device == "quest":
                    # 使用Pico VR控制机械臂
                    if self.startflag and start_trigger:
                        self._control_arm_with_pico()
                    else:
                        self.arm_init = False
                elif self.arm_device == "pico_wrist":
                    if self.startflag and start_trigger:
                        self._control_arm_with_wrist()
                    else:
                        self.arm_init = False

                # 手部控制逻辑修改
                if self.eef_type not in ["none", "G2"]:
                    if (
                        self.hand_device == "udexreal"
                        and hasattr(self, "hand_teleoperator")
                        and self.hand_teleoperator
                    ):
                        # 使用宇叠手套数据
                        self.hand_ctrl_data = self.hand_teleoperator.get_hand_data()
                    elif self.hand_device == "pico" or self.arm_device == "quest":
                        # 保持现有的Pico手部控制逻辑
                        # if self.startflag and self.vr_ctrl_data["LTr"]:
                        self._control_hand_with_pico()
                elif self.eef_type == "G2":

                    self.tctr_gripper = (
                        self.INIT_GRIPPER - self.INIT_GRIPPER * gripper**2
                    )
                    # self.arm.update_eef(self.tctr_gripper)

                if self.base_type == "go2":
                    self.handle_go2_control()
                elif self.base_type == "d1":
                    self.handle_d1_control()

            elif self.robot_type == "airbot_tok2":
                if self.arm_device == "pico" or self.arm_device == "quest":
                    # 使用Pico VR控制机械臂
                    if self.startflag:
                        self._control_tok2_with_pico(
                            start_trigger_left, start_trigger_right
                        )
                    else:
                        self.arm_init = False
                elif self.arm_device == "pico_wrist":
                    if self.startflag:
                        self._control_arm_with_wrist(
                            start_trigger_left, start_trigger_right
                        )
                    else:
                        self.arm_init = False

                if self.eef_type_left == "G2" and self.eef_type_right == "G2":

                    self.tctr_gripper_left = (
                        self.INIT_GRIPPER - self.INIT_GRIPPER * gripper_left**2
                    )
                    self.tctr_gripper_right = (
                        self.INIT_GRIPPER - self.INIT_GRIPPER * gripper_right**2
                    )

            time.sleep(1.0 / self.pub_freq)

    def _control_arm_with_pico(self):
        """使用Pico VR控制机械臂"""
        try:
            if self.handedness == "left":
                vr_trans = self.left_info.data[:3]
                vr_quat = self.left_info.data[3:7]
            if self.handedness == "right":
                vr_trans = self.right_info.data[:3]
                vr_quat = self.right_info.data[3:7]
            vr_trans = np.array(vr_trans, dtype=float)
            vr_quat = np.array(vr_quat, dtype=float)
            vr_cur_pose = self.pose_transform_to_matrix(vr_trans, vr_quat)

            # 初始化偏置
            if not self.arm_init:
                self.trans_init = np.array(vr_trans)
                self.quat_init = np.array(vr_quat)
                self.vr_init_pose = self.pose_transform_to_matrix(
                    self.trans_init, self.quat_init
                )
                arm_end_pose = self.arm.get_end_pose()
                self.arm_init_pose = self.pose_transform_to_matrix(
                    arm_end_pose[0], arm_end_pose[1]
                )
                print_green(f"VR初始位置: {self.trans_init}")
                print_green(f"VR初始朝向: {self.quat_init}")
                print_green(f"机械臂末端初始位姿: {self.arm_init_pose}\n")
                self.arm_init = True

            relative_transform = np.dot(np.linalg.inv(self.vr_init_pose), vr_cur_pose)
            T_left = np.dot(self.arm_init_pose, relative_transform)

            self.arm.update_arm(T_left)
        except Exception as e:
            print_red(f"Pico VR臂控制出错: {str(e)}\n")

    def _control_arm_with_wrist(self):
        """使用Pico腕带控制机械臂"""
        try:
            if self.handedness == "left":
                vr_trans = self.left_info.data[:3]
                vr_quat = self.left_info.data[3:7]
            if self.handedness == "right":
                vr_trans = self.left_info.data[:3]
                vr_quat = self.left_info.data[3:7]
            vr_trans = np.array(vr_trans, dtype=float)
            vr_quat = np.array(vr_quat, dtype=float)
            vr_cur_pose = self.pose_transform_to_matrix(vr_trans, vr_quat)

            # 初始化偏置
            if not self.arm_init:
                self.trans_init = np.array(vr_trans)
                self.quat_init = np.array(vr_quat)
                self.vr_init_pose = self.pose_transform_to_matrix(
                    self.trans_init, self.quat_init
                )
                arm_end_pose = self.arm.get_end_pose()
                self.arm_init_pose = self.pose_transform_to_matrix(
                    arm_end_pose[0], arm_end_pose[1]
                )
                print_green(f"腕带初始位置: {self.trans_init}")
                print_green(f"腕带初始朝向: {self.quat_init}")
                print_green(f"机械臂末端初始位姿: {self.arm_init_pose}\n")
                self.arm_init = True

            relative_transform = np.dot(np.linalg.inv(self.vr_init_pose), vr_cur_pose)
            T_left = np.dot(self.arm_init_pose, relative_transform)

            self.arm.update_arm(T_left)

        except Exception as e:
            print(self.left_info.data)
            print_red(f"腕带臂控制出错: {str(e)}\n")

    def _control_tok2_with_pico(self, start_trigger_left, start_trigger_right):
        """使用Pico VR控制机械臂"""
        try:
            vr_trans_left = self.left_info.data[:3]
            vr_quat_left = self.left_info.data[3:7]
            vr_trans_right = self.right_info.data[:3]
            vr_quat_right = self.right_info.data[3:7]

            vr_trans_left = np.array(vr_trans_left, dtype=float)
            vr_trans_right = np.array(vr_trans_right, dtype=float)

            vr_quat_left = np.array(vr_quat_left, dtype=float)
            vr_quat_right = np.array(vr_quat_right, dtype=float)

            vr_cur_pose_left = self.pose_transform_to_matrix(
                vr_trans_left, vr_quat_left
            )
            vr_cur_pose_right = self.pose_transform_to_matrix(
                vr_trans_right, vr_quat_right
            )

            if start_trigger_left:
                # 初始化偏置
                if not self.arm_init_left:
                    self.trans_init_left = np.array(vr_trans_left)
                    self.quat_init_left = np.array(vr_quat_left)
                    self.vr_init_pose_left = self.pose_transform_to_matrix(
                        self.trans_init_left, self.quat_init_left
                    )
                    arm_end_pose_left = self.arm_left.get_end_pose()
                    self.arm_init_pose_left = self.pose_transform_to_matrix(
                        arm_end_pose_left[0], arm_end_pose_left[1]
                    )
                    print_green(f"VR初始位置: {self.trans_init_left}")
                    print_green(f"VR初始朝向: {self.quat_init_left}")
                    print_green(f"机械臂末端初始位姿: {self.arm_init_pose_left}\n")
                    self.arm_init_left = True

                relative_transform_left = np.dot(
                    np.linalg.inv(self.vr_init_pose_left), vr_cur_pose_left
                )
                T_left = np.dot(self.arm_init_pose_left, relative_transform_left)

                self.arm_left.update_arm(T_left)
            else:
                self.arm_init_left = False

            if start_trigger_right:
                # 初始化偏置
                if not self.arm_init_right:
                    self.trans_init_right = np.array(vr_trans_right)
                    self.quat_init_right = np.array(vr_quat_right)
                    self.vr_init_pose_right = self.pose_transform_to_matrix(
                        self.trans_init_right, self.quat_init_right
                    )
                    arm_end_pose_right = self.arm_right.get_end_pose()
                    self.arm_init_pose_right = self.pose_transform_to_matrix(
                        arm_end_pose_right[0], arm_end_pose_right[1]
                    )
                    print_green(f"VR初始位置: {self.trans_init_right}")
                    print_green(f"VR初始朝向: {self.quat_init_right}")
                    print_green(f"机械臂末端初始位姿: {self.arm_init_pose_right}\n")
                    self.arm_init_right = True

                relative_transform_right = np.dot(
                    np.linalg.inv(self.vr_init_pose_right), vr_cur_pose_right
                )
                T_right = np.dot(self.arm_init_pose_right, relative_transform_right)

                self.arm_right.update_arm(T_right)
            else:
                self.arm_init_right = False
        except Exception as e:
            print_red(f"Pico VR臂控制出错: {str(e)}\n")

    def _control_tok2_with_wrist(self, start_trigger_left, start_trigger_right):
        """使用Pico腕带控制机械臂"""
        try:
            vr_trans_left = self.left_info.data[:3]
            vr_quat_left = self.left_info.data[3:7]
            vr_trans_right = self.right_info.data[:3]
            vr_quat_right = self.right_info.data[3:7]

            vr_trans_left = np.array(vr_trans_left, dtype=float)
            vr_trans_right = np.array(vr_trans_right, dtype=float)

            vr_quat_left = np.array(vr_quat_left, dtype=float)
            vr_quat_right = np.array(vr_quat_right, dtype=float)

            vr_cur_pose_left = self.pose_transform_to_matrix(
                vr_trans_left, vr_quat_left
            )
            vr_cur_pose_right = self.pose_transform_to_matrix(
                vr_trans_right, vr_quat_right
            )

            if start_trigger_left:
                # 初始化偏置
                if not self.arm_init_left:
                    self.trans_init_left = np.array(vr_trans_left)
                    self.quat_init_left = np.array(vr_quat_left)
                    self.vr_init_pose_left = self.pose_transform_to_matrix(
                        self.trans_init_left, self.quat_init_left
                    )
                    arm_end_pose_left = self.arm_left.get_end_pose()
                    self.arm_init_pose_left = self.pose_transform_to_matrix(
                        arm_end_pose_left[0], arm_end_pose_left[1]
                    )
                    print_green(f"VR初始位置: {self.trans_init_left}")
                    print_green(f"VR初始朝向: {self.quat_init_left}")
                    print_green(f"机械臂末端初始位姿: {self.arm_init_pose_left}\n")
                    self.arm_init_left = True

                relative_transform_left = np.dot(
                    np.linalg.inv(self.vr_init_pose_left), vr_cur_pose_left
                )
                T_left = np.dot(self.arm_init_pose_left, relative_transform_left)

                self.arm_left.update_arm(T_left)
            else:
                self.arm_init_left = False

            if start_trigger_right:
                # 初始化偏置
                if not self.arm_init_right:
                    self.trans_init_right = np.array(vr_trans_right)
                    self.quat_init_right = np.array(vr_quat_right)
                    self.vr_init_pose_right = self.pose_transform_to_matrix(
                        self.trans_init_right, self.quat_init_right
                    )
                    arm_end_pose_right = self.arm_right.get_end_pose()
                    self.arm_init_pose_right = self.pose_transform_to_matrix(
                        arm_end_pose_right[0], arm_end_pose_right[1]
                    )
                    print_green(f"VR初始位置: {self.trans_init_right}")
                    print_green(f"VR初始朝向: {self.quat_init_right}")
                    print_green(f"机械臂末端初始位姿: {self.arm_init_pose_right}\n")
                    self.arm_init_right = True

                relative_transform_right = np.dot(
                    np.linalg.inv(self.vr_init_pose_right), vr_cur_pose_right
                )
                T_right = np.dot(self.arm_init_pose_right, relative_transform_right)

                self.arm_right.update_arm(T_right)
            else:
                self.arm_init_right = False
        except Exception as e:
            print_red(f"Pico VR臂控制出错: {str(e)}\n")

    def _control_hand_with_pico(self):
        """使用Pico VR控制手部"""
        hand_control_value = [
            self.vr_ctrl_data["rightJS"]["ud"],
            self.vr_ctrl_data["leftJS"]["lr"],
            self.vr_ctrl_data["rightJS"]["lr"],
            self.vr_ctrl_data["rightJS"]["lr"],
            self.vr_ctrl_data["rightJS"]["lr"],
            self.vr_ctrl_data["rightJS"]["lr"],
        ]

        for i in range(6):
            self.hand_ctrl_data[i] = self.update_hand_pose(
                i, hand_control_value[i], self.hand_control_threshold[i]
            )

    def pose_transform_to_matrix(self, pos, rot):
        pos = np.array(pos, dtype=float)
        quat = np.array(rot, dtype=float)
        rotation = Rotation.from_quat(quat).as_matrix()
        trans = np.eye(4)
        trans[:3, :3] = rotation
        trans[:3, 3] = pos
        return trans

    def update_hand_pose(self, i, control_value, control_threshold):
        threshold = 0.7
        step_size = 15
        cur_hand_pose = self.hand_ctrl_data[i]
        if control_value > threshold:
            return min(control_threshold[1], cur_hand_pose + step_size)
        elif control_value < -threshold:
            return max(control_threshold[0], cur_hand_pose - step_size)
        else:
            return cur_hand_pose

    def release(self):
        print_yellow("disconnect robot")
        if hasattr(self, "timer"):
            self.timer.destroy()

        # 清理手部遥操作器
        if hasattr(self, "hand_teleoperator") and self.hand_teleoperator:
            self.hand_teleoperator.stop()
        print_yellow("start release arm")
        if self.robot_type == "airbot_play":
            self.arm.release()
        elif self.robot_type == "airbot_tok2":
            self.arm_left.release()
            self.arm_right.release()
        print_yellow("arm released")

    def handle_go2_control(self):
        if self.handedness == "right":
            trigger = self.vr_ctrl_data["leftGrip"]
            left_joy_x = self.vr_ctrl_data["leftJS"]["ud"]
            right_joy_y = -self.vr_ctrl_data["leftJS"]["lr"]
        elif self.handedness == "left":
            trigger = self.vr_ctrl_data["rightGrip"]
            left_joy_x = self.vr_ctrl_data["rightJS"]["ud"]
            right_joy_y = -self.vr_ctrl_data["rightJS"]["lr"]

        # 右手柄食指扳机控制站立/卧倒
        if trigger > 0.8:
            if self.is_standing:
                self.send_go2_command("stand_down")
                self.is_standing = False
            else:
                self.send_go2_command("stand_up")
                self.is_standing = True
            time.sleep(0.5)

        # 只有在站立状态下才能控制移动
        if not self.is_standing:
            return

        x_move = (
            left_joy_x * self.MOVE_SPEED
            if abs(left_joy_x) > self.JOYSTICK_DEADZONE
            else 0
        )
        # y_move = left_joy_y * self.MOVE_SPEED if abs(left_joy_y) > self.JOYSTICK_DEADZONE else 0
        z_rotate = (
            right_joy_y * self.ROTATE_SPEED
            if abs(right_joy_y) > self.JOYSTICK_DEADZONE
            else 0
        )

        if abs(right_joy_y) > self.JOYSTICK_DEADZONE:
            self.head_angle += right_joy_y * self.HEAD_SPEED * 1 / 250
            self.head_angle = np.clip(self.head_angle, -0.5, 0.5)
            self.send_go2_command("set_head_angle", {"angle": self.head_angle})

        if x_move != 0 or z_rotate != 0:
            self.send_go2_command("move", {"x": x_move, "y": 0, "z": z_rotate})
        else:
            self.send_go2_command("stop_move")

    def handle_d1_control(self):
        if self.handedness == "right":
            trigger = self.vr_ctrl_data["leftGrip"]
            start = self.vr_ctrl_data["LJ"]
            left_joy_x = self.vr_ctrl_data["leftJS"]["ud"]
            right_joy_y = -self.vr_ctrl_data["leftJS"]["lr"]
        elif self.handedness == "left":
            trigger = self.vr_ctrl_data["rightGrip"]
            start = self.vr_ctrl_data["RJ"]
            left_joy_x = self.vr_ctrl_data["rightJS"]["ud"]
            right_joy_y = -self.vr_ctrl_data["rightJS"]["lr"]

        # 右手柄食指扳机控制站立/卧倒
        if trigger > 0.8:
            if self.is_standing:
                self.send_d1_command("stand_down")
                self.is_standing = False
            else:
                self.send_d1_command("stand_up")
                self.is_standing = True
            time.sleep(0.5)

        # 只有在站立状态下才能控制移动
        if not self.is_standing:
            return

        if start:
            if self.is_move == False:
                self.is_move = True
                print("loco")
                time.sleep(0.8)
                self.send_d1_command("switch_mode", {"mode": "loco"})
            else:
                self.is_move = False
                self.send_d1_command("switch_mode", {"mode": "joint_pd"})
                print("joint_pd")
                time.sleep(0.8)

        x_move = (
            left_joy_x * self.MOVE_SPEED + 0.08
            if abs(left_joy_x) > self.JOYSTICK_DEADZONE
            else 0
        )
        # y_move = left_joy_y * self.MOVE_SPEED if abs(left_joy_y) > self.JOYSTICK_DEADZONE else 0
        z_rotate = (
            right_joy_y * self.ROTATE_SPEED
            if abs(right_joy_y) > self.JOYSTICK_DEADZONE
            else 0
        )

        # if abs(right_joy_y) > self.JOYSTICK_DEADZONE:
        #     self.head_angle += right_joy_y * self.HEAD_SPEED * 1 / 250
        #     self.head_angle = np.clip(self.head_angle, -0.5, 0.5)
        #     self.send_go2_command("set_head_angle", {"angle": self.head_angle})

        if x_move != 0 or z_rotate != 0:
            self.send_d1_command("move", {"x": x_move, "y": 0, "z": z_rotate})
            # print({f"x": x_move, "y": 0, "z": z_rotate})
        else:
            self.send_d1_command("stop_move")

    def send_go2_command(self, action, params=None):
        """发送命令到Go2机器人的ZMQ服务器"""
        if params is None:
            params = {}

        try:
            command = json.dumps({"action": action, "params": params})
            self.go2_socket.send_string(command)
            response = json.loads(self.go2_socket.recv_string())

            return response
        except Exception as e:
            print_red(f"发送Go2命令出错: {str(e)}")
            return {"status": "error", "message": str(e)}

    def send_d1_command(self, action, params=None):
        """发送命令到d1机器人的ZMQ服务器"""
        if params is None:
            params = {}

        try:
            command = json.dumps({"action": action, "params": params})
            self.d1_socket.send_string(command)
            # response = json.loads(self.d1_socket.recv_string())

            # return response
        except Exception as e:
            print_red(f"发送D1命令出错: {str(e)}")
            return {"status": "error", "message": str(e)}


if __name__ == "__main__":
    import threading
    import os

    parser = argparse.ArgumentParser(description="airbot vr")
    parser.add_argument("-p", default="configs/task.yaml", help="task.yaml path")
    args = parser.parse_args()

    path = args.p
    if not os.path.isfile(path):
        print(f"❌ 文件不存在: {path}")
        sys.exit(1)
    # print_green(path)

    vr_arm_node = None
    ros_thread = None

    # vr_arm_node = VRArm(path)

    try:
        vr_arm_node = VRArm(path)

        try:
            while vr_arm_node.running:
                if vr_arm_node.robot_type == "airbot_play":
                    if vr_arm_node.eef_type == "none":
                        pass
                    elif vr_arm_node.eef_type == "G2":
                        vr_arm_node.arm.update_eef(vr_arm_node.tctr_gripper)
                    else:
                        eef_cmd = vr_arm_node.arm.robot.eef.eef_cmd
                        eef_cmd.positions = [
                            max(0, min(1000, round(x)))
                            for x in vr_arm_node.hand_ctrl_data
                        ]
                        eef_cmd.velocities = [1000, 1000, 1000, 1000, 1000, 1000]
                        vr_arm_node.arm.robot.eef.eef.set_pos(eef_cmd)
                elif vr_arm_node.robot_type == "airbot_tok2":
                    if (
                        vr_arm_node.eef_type_left == "G2"
                        and vr_arm_node.eef_type_right == "G2"
                    ):
                        vr_arm_node.arm_left.update_eef(vr_arm_node.tctr_gripper_left)
                        vr_arm_node.arm_right.update_eef(vr_arm_node.tctr_gripper_right)

                time.sleep(1 / vr_arm_node.hand_control_freq)

        except KeyboardInterrupt:
            print_yellow("\n收到 Ctrl+C 信号，正在关闭程序...")
            vr_arm_node.running = False

    except Exception as e:
        import traceback

        traceback.print_exc()
    finally:
        # 清理
        if ProcessHandler.process is not None:
            returncode = ProcessHandler.process.poll()
            print(f"进程返回码: {returncode}")

            if returncode is None:
                print("进程仍在运行，正在终止...")
                ProcessHandler.process.terminate()
                try:
                    ProcessHandler.process.wait(timeout=5)
                    print("进程已停止")
                except subprocess.TimeoutExpired:
                    print("进程未响应，强制杀死...")
                    ProcessHandler.process.kill()
                    ProcessHandler.process.wait()
                    print("进程已被强制杀死")
            else:
                print(f"进程已退出，返回码: {returncode}")

        if ProcessHandler.process_go2 is not None:
            returncode = ProcessHandler.process_go2.poll()
            print(f"进程返回码: {returncode}")

            if returncode is None:
                print("进程仍在运行，正在终止...")
                ProcessHandler.process_go2.terminate()
                try:
                    ProcessHandler.process_go2.wait(timeout=1)
                    print("GO2进程已停止")
                except subprocess.TimeoutExpired:
                    print("进程未响应，强制杀死...")
                    ProcessHandler.process_go2.kill()
                    ProcessHandler.process_go2.wait()
                    print("GO2进程已被强制杀死")
            else:
                print(f"进程已退出，返回码: {returncode}")

        if vr_arm_node is not None:
            vr_arm_node.reset_pose()
            vr_arm_node.release()
        print("=== 资源清理完成 ===")
