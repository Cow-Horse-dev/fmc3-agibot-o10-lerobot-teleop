if __name__ == "__main__" and __package__ is None:
    __package__ = "airbot_vr.robot.ddt"
