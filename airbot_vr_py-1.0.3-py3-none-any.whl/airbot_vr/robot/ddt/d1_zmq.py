import zmq
import json
import threading
import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy, HistoryPolicy


class D1Zmq(Node):
    """
    通过ZMQ协议远程控制D1机器人的类
    """

    def __init__(self, zmq_address="tcp://localhost:8002", vis=False):
        super().__init__("d1_publisher_node")
        """
        初始化ZMQ服务器和机器人客户端

        Args:
            zmq_address (str): ZMQ服务器绑定地址，默认tcp://localhost:8002
            vis (bool): 是否启用视频显示
        """

        qos_profile = QoSProfile(
            depth=10,  # 队列深度
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,  # 改为TRANSIENT_LOCAL
            history=HistoryPolicy.KEEP_LAST,
        )

        twist_qos = QoSProfile(
            depth=10,  # 队列深度
            reliability=ReliabilityPolicy.RELIABLE,  # 关键：改为RELIABLE
            durability=DurabilityPolicy.TRANSIENT_LOCAL,  # 关键：改为TRANSIENT_LOCAL
            history=HistoryPolicy.KEEP_LAST,
        )

        self.cmd_twist_publisher = self.create_publisher(
            Twist, "/d15020100/command/cmd_twist", twist_qos  # 话题名称  # QoS队列大小
        )

        # 创建String类型发布者
        self.cmd_key_publisher = self.create_publisher(
            String, "/d15020100/command/cmd_key", qos_profile
        )

        # 初始化ZMQ上下文和socket
        self.d1_context = zmq.Context()
        self.d1_socket = self.d1_context.socket(zmq.SUB)
        self.d1_socket.bind(zmq_address)
        self.d1_socket.setsockopt_string(zmq.SUBSCRIBE, "")
        self.d1_socket.setsockopt(zmq.LINGER, 0)
        print(f"ZMQ服务器已启动，绑定地址: {zmq_address}")

        self.running = True

        # 启动命令处理线程
        self.command_thread = threading.Thread(
            target=self._process_commands, daemon=True
        )
        self.command_thread.start()

    def _process_commands(self):
        """处理接收到的ZMQ命令"""
        print("开始处理命令...")
        try:
            while self.running:
                # 等待接收命令
                message = self.d1_socket.recv_string()
                # print(f"收到命令: {message}")

                try:
                    # 解析JSON命令
                    command = json.loads(message)
                    # print(command)
                    response = self._execute_command(command)
                except json.JSONDecodeError:
                    response = {"status": "error", "message": "无效的JSON格式"}
                except Exception as e:
                    response = {"status": "error", "message": f"命令执行错误: {str(e)}"}

                # 发送响应
                # self.d1_socket.send_string(json.dumps(response))
        except Exception as e:
            print(f"命令处理线程错误: {str(e)}")

    def _execute_command(self, command):
        """执行解析后的命令"""
        if "action" not in command:
            return {"status": "error", "message": "命令中缺少'action'字段"}

        action = command["action"]
        params = command.get("params", {})

        # 根据动作执行相应的方法
        try:
            if action == "stand_up":
                string_msg = String()
                string_msg.data = "transform_up"
                self.cmd_key_publisher.publish(string_msg)
                time.sleep(1)  # 等待动作完成
                return {"status": "success", "message": "已执行站立动作"}

            elif action == "stand_down":
                string_msg = String()
                string_msg.data = "transform_down"
                self.cmd_key_publisher.publish(string_msg)
                time.sleep(1)  # 等待动作完成
                return {"status": "success", "message": "已执行蹲下动作"}

            elif action == "move":
                x = params.get("x", 0.0)
                y = params.get("y", 0.0)
                z = params.get("z", 0.0)

                twist_msg = Twist()
                twist_msg.linear.x = float(x)
                twist_msg.angular.z = float(z)
                # print({f"x": x, "y": 0, "z": z})

                self.cmd_twist_publisher.publish(twist_msg)

                return {"status": "success", "message": f"已执行移动: x={x}, y={y}, z={z}"}

            elif action == "stop_move":
                twist_msg = Twist()
                twist_msg.linear.x = 0.08
                twist_msg.angular.z = 0.0
                self.cmd_twist_publisher.publish(twist_msg)
                return {"status": "success", "message": "已停止移动"}

            elif action == "switch_mode":
                mode = params.get("mode", "joint_pd")
                string_msg = String()
                string_msg.data = mode
                self.cmd_key_publisher.publish(string_msg)
                time.sleep(1)
                return {"status": "success", "message": f"已切换步态: {mode}"}

            elif action == "exit":
                self.stop()
                return {"status": "success", "message": "正在退出程序"}

            else:
                return {"status": "error", "message": f"未知动作: {action}"}

        except Exception as e:
            return {"status": "error", "message": f"执行动作时出错: {str(e)}"}

    def stop(self):
        """停止服务器并清理资源"""
        self.running = False
        print("正在停止ZMQ服务器...")

        # 关闭ZMQ连接
        self.d1_socket.close()
        self.d1_context.term()
        print("ZMQ服务器已停止")


if __name__ == "__main__":
    import sys

    rclpy.init()

    zmq_port = sys.argv[1] if len(sys.argv) > 1 else "8002"
    zmq_address = f"tcp://localhost:{zmq_port}"

    try:
        # 创建并启动ZMQ控制器
        controller = D1Zmq(zmq_address)

        # 保持主程序运行
        while controller.running:
            time.sleep(1)

    except KeyboardInterrupt:
        print("用户中断程序")
    except Exception as e:
        print(f"程序出错: {str(e)}")
    finally:
        if "controller" in locals():
            controller.stop()
        print("程序已退出")
